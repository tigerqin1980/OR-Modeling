# Shared by build.ps1 and run.ps1. Paths are supplied through environment variables.
function Get-SolverConfig([string]$Solver) {
    $variable = if ($Solver -eq 'Gurobi') { 'GUROBI_HOME' } else { 'COPT_HOME' }
    $jarName = if ($Solver -eq 'Gurobi') { 'gurobi.jar' } else { 'copt.jar' }
    $solverRoot = [Environment]::GetEnvironmentVariable($variable)
    if (-not $solverRoot) {
        throw "Set $variable to your solver installation directory (containing lib and bin)."
    }
    $jar = Join-Path $solverRoot "lib/$jarName"
    $nativeDir = Join-Path $solverRoot 'bin'
    if (-not (Test-Path -LiteralPath $jar -PathType Leaf)) {
        throw "Solver JAR not found: $jar"
    }
    if (-not (Test-Path -LiteralPath $nativeDir -PathType Container)) {
        throw "Solver native-library directory not found: $nativeDir"
    }
    return @{ Jar = $jar; NativeDir = $nativeDir }
}
