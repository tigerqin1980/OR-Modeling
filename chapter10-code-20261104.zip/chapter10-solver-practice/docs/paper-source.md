# 原始模型来源

Huang, Qin, Du, Wang (2024), EJOR 319, 31–49, DOI: 10.1016/j.ejor.2024.06.025。

[出版社补充材料](https://ars.els-cdn.com/content/image/1-s2.0-S0377221724004739-mmc1.pdf)，下载日期2026-11-04。
SHA256：`4292bccd14e8b6380f86c7f8904880e5e8a0716487e1486db2bcbede772e5df2`。
Appendix A位于附件第1—2页，共33个编号公式。本代码以该弧流模型为依据。

本仓库提供来源链接，不把原论文PDF作为源码文件分发。附件本地副本单独交付给作者。
