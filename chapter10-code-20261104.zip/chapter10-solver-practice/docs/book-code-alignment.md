# Appendix A—10.7.3—代码对应

源文档与哈希见paper-source.md。两个求解器使用同样的数学模型，注释标注原附录编号。

| 附录 | 代码 |
| --- | --- |
| A.1 | 行驶成本及累计人数差分成本 |
| A.2 | flow_in、flow_out |
| A.3 | trip_start；含xStart[k][0]的等式 |
| A.4 | start_link |
| A.5 | visit |
| A.6 | start_member |
| A.7 | trip_cons_1、trip_cons_2，二进制条件的等价线性化 |
| A.8–10 | time_link、return_time、depart_time |
| A.11 | lunch_once；每辆给定车辆右端为1 |
| A.12 | lunch_link |
| A.13 | assign |
| A.14–15 | veh_order_1、veh_order_2 |
| A.16 | veh_time，增加车辆午休时长 |
| A.17–18 | staff_order_1、staff_order_2 |
| A.19 | staff_time，增加行程后午休时长 |
| A.20 | skill_req，覆盖前a级累计需求 |
| A.21 | staff_count，累计实际人员分配 |
| A.22 | capacity，患者与工作人员共同占座 |
| A.23 | a[i]上下界 |
| A.24 | dep、ret上下界及trip_time |
| A.25–26 | lunch_lb、lunch_ub、lunch_depart |
| A.27–33及变量定义 | 二进制/整数类型、时间下界；变量域依照附录开头的明确定义 |

变量映射：x→x_ij；xStart→x^k_0i；z→δ；v→ξ；w→y；staffAssign→φ；staffOrder→χ；nStaff→ζ；a→u；dep/ret→τstart/τend；lunch→lu。

## 明确的实现处理

1. 附录A.27写作x^k_ij，与前面的二维x_ij及x^k_0i定义不一致。实现按变量定义及A.1–A.10的使用方式，为二维x和行程起点xStart分别设置二进制类型；lunch为二进制，ζ为非负整数。
2. A.7作等价线性化；对称成对约束只生成k<l，时序约束仍生成所有k!=l；零需求覆盖恒真式省略。
3. 原附录说明统一M=T；代码按时间窗计算足够大的常数，含午休接续取l0-e0+L。保留约束逻辑，避免固定T不足以松弛未激活约束。这不是对附录M数值的逐字复刻。
4. ζ的上界由A.21推得累计可用人数，本例为1、4。人员费用已按A.1差分计费。
5. A.11右端为1，附录没有eta。MSM给定车辆数不是允许闲置的车队上限。空行程允许，但不能为未出车的车辆安排午休。
6. 按A.25–A.26保留非严格边界；不采用正文图8的新三类行程约束、不新增个人午休模型、不加入固定班组约束。
7. 示例限定两类人员、正客户服务时间。默认16客户、2辆给定车辆、容量12、6候选行程、3600秒；t_min属于集合覆盖算法，不使用。

第6章需将增加的eta及其联动撤回，恢复A.11原式；删除“全天同车”的说明。第10章按附录模型和当前代码同步。
