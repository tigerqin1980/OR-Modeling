package tests;

import common.SolutionIO;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 对可手算算例检查输出；不依赖商业求解器API。 */
public final class SolverResultTest {
    private SolverResultTest() {}

    public static void main(String[] args) throws Exception {
        String solver = args[0];
        check("tiny-vrptw_VRPTW_" + solver, 6, 3, false);
        check("tiny-vrptw_SDVRPTWL_" + solver, 6, 3, true);
        check("tiny-vrptw_MTVRPTW_" + solver, 6, 3, false);
        check("tiny-msm_MTVRPTW_MSM_" + solver, 91, 3, false);
        check("tiny-split_SDVRPTWL_" + solver, 4, 1, true);
        SolutionIO.SolutionData staff = check(
                "tiny-msm-four-staff_MTVRPTW_MSM_" + solver, 167, 1, false);
        require(staff.routes.size() == 1, "One trip should serve the four-staff instance.");

        String text = Files.readString(path("tiny-msm-four-staff_MTVRPTW_MSM_" + solver));
        require(text.contains("staffCum=1,4"), "Cumulative staff upper bound must allow four people.");
        Matcher staffIds = Pattern.compile("staffIds=([^\\s]+)").matcher(text);
        require(staffIds.find(), "Missing assigned staff IDs.");
        Set<String> assigned = new HashSet<>(List.of(staffIds.group(1).split(",")));
        require(assigned.size() == 4, "Four distinct staff members must be assigned.");
        Matcher lunch = Pattern.compile("lunchVehicle=([12])").matcher(text);
        require(lunch.find() && !lunch.find(), "The single given vehicle must take exactly one lunch (A.11).");

        String splitText = Files.readString(path("tiny-split_SDVRPTWL_" + solver));
        Matcher deliveries = Pattern.compile(
                "delivery vehicle=(\\d+) customer=1 amount=([^\\s]+)").matcher(splitText);
        Map<Integer, Double> amounts = new HashMap<>();
        while (deliveries.find()) {
            amounts.merge(Integer.parseInt(deliveries.group(1)),
                    Double.parseDouble(deliveries.group(2)), Double::sum);
        }
        require(amounts.size() == 2, "Demand 35 with capacity 30 requires two deliveries.");
        double total = 0;
        for (double amount : amounts.values()) {
            require(amount > 0 && amount <= 30 + 1e-6, "Vehicle capacity exceeded.");
            total += amount;
        }
        close(total, 35);
        checkLunchSequence(solver);
        checkAppendixFleet(solver);
        System.out.println("SolverResultTest: ten " + solver + " cases passed.");
    }

    /** 一辆车、同一高技能人员必须执行两趟，午休位于两趟之间。 */
    private static void checkLunchSequence(String solver) throws Exception {
        Path result = path("tiny-msm-two-trips_MTVRPTW_MSM_" + solver);
        SolutionIO.SolutionData data = SolutionIO.readSolution(result.toString());
        require(data.status.equals(solver.equals("Gurobi") ? "2" : "1"), "Two-trip case must be optimal.");
        close(data.objective, 94); // 两趟距离各2，人员成本各45。
        close(data.gap, 0);
        require(data.routes.size() == 2, "Capacity requires two nonempty trips; third slot stays empty.");
        Set<Integer> customers = new HashSet<>();
        for (List<Integer> route : data.routes) {
            require(route.size() == 3 && route.get(0) == 0 && route.get(2) == 0,
                    "Each trip must visit one customer and return to depot.");
            require(customers.add(route.get(1)), "Customers must not repeat.");
        }
        require(customers.equals(Set.of(1, 2)), "Both customers must be served.");
        List<Map<String, String>> jobs = new java.util.ArrayList<>();
        for (String line : Files.readAllLines(result)) {
            if (!line.startsWith("schedule ")) continue;
            Matcher matcher = Pattern.compile("(\\w+)=([^\\s]+)").matcher(line);
            Map<String, String> values = new HashMap<>();
            while (matcher.find()) values.put(matcher.group(1), matcher.group(2));
            jobs.add(values);
        }
        require(jobs.size() == 2, "Missing schedule details.");
        jobs.sort(java.util.Comparator.comparingDouble(j -> Double.parseDouble(j.get("departure"))));
        Map<String, String> first = jobs.get(0), second = jobs.get(1);
        double depart = Double.parseDouble(first.get("departure"));
        double returned = Double.parseDouble(first.get("return"));
        require(depart <= 40 + 1e-6 && returned >= 40 - 1e-6 && returned <= 60 + 1e-6,
                "Lunch trip must depart before the window and return inside it.");
        require("1".equals(first.get("lunchVehicle")) && !second.containsKey("lunchVehicle"),
                "Used vehicle takes exactly one lunch after the first trip.");
        require(returned + 10 <= Double.parseDouble(second.get("departure")) + 1e-6,
                "Vehicle and worker must finish lunch before the second trip.");
        require("1,1".equals(first.get("staffCum")) && "1,1".equals(second.get("staffCum")),
                "Both trips need one high-skilled worker.");
        require(first.get("staffIds").equals(second.get("staffIds")), "Only one high-skilled worker is available.");

        // 按附录A.11、A.25的原式，只有下午行程的给定车辆不可行。
        SolutionIO.SolutionData late = SolutionIO.readSolution(
                path("tiny-msm-late-only_MTVRPTW_MSM_" + solver).toString());
        require(late.status.equals(solver.equals("Gurobi") ? "3" : "2"), "Late-only case must be infeasible.");
        require(late.routes.isEmpty() && late.objective == null, "Infeasible output must not contain a stale solution.");
    }

    private static void checkAppendixFleet(String solver) throws Exception {
        SolutionIO.SolutionData fleet = SolutionIO.readSolution(
                path("tiny-msm-fleet-required_MTVRPTW_MSM_" + solver).toString());
        require(fleet.status.equals(solver.equals("Gurobi") ? "3" : "2"),
                "A.11 requires both given vehicles to take a trip; one available trip is insufficient.");
        require(fleet.routes.isEmpty() && fleet.objective == null, "Infeasible fleet output must contain no solution.");
        SolutionIO.SolutionData returning = SolutionIO.readSolution(
                path("tiny-msm-return-lunch_MTVRPTW_MSM_" + solver).toString());
        require(returning.status.equals(solver.equals("Gurobi") ? "2" : "1"), "Return-lunch case must be optimal.");
        close(returning.objective, 94);
        close(returning.gap, 0);
    }

    private static SolutionIO.SolutionData check(
            String name, double objective, int customers, boolean split) throws Exception {
        SolutionIO.SolutionData data = SolutionIO.readSolution(path(name).toString());
        require(data.objective != null && data.lowerBound != null && data.gap != null,
                name + ": missing objective/bound/gap.");
        require(data.status.equals(name.endsWith("Gurobi") ? "2" : "1"),
                name + ": expected optimal status.");
        close(data.objective, objective);
        close(data.lowerBound, objective);
        close(data.gap, 0);
        int[] visits = new int[customers + 1];
        double distance = 0;
        require(!data.routes.isEmpty(), name + ": no routes.");
        for (List<Integer> route : data.routes) {
            require(route.get(0) == 0 && route.get(route.size() - 1) == 0,
                    name + ": route must start and end at the depot.");
            Set<Integer> onRoute = new HashSet<>();
            for (int i = 1; i < route.size() - 1; i++) {
                int node = route.get(i);
                require(node >= 1 && node <= customers && onRoute.add(node),
                        name + ": invalid or repeated customer.");
                visits[node]++;
            }
            for (int i = 1; i < route.size(); i++) {
                distance += Math.abs(route.get(i) - route.get(i - 1));
            }
        }
        for (int i = 1; i <= customers; i++) {
            require(split ? visits[i] >= 1 : visits[i] == 1, name + ": missing/duplicated customer " + i);
        }
        close(distance, name.startsWith("tiny-msm-four") ? 2 : name.startsWith("tiny-split") ? 4 : 6);
        return data;
    }

    private static Path path(String name) {
        return Path.of("solutions", name + ".txt");
    }

    private static void close(double actual, double expected) {
        require(Math.abs(actual - expected) < 1e-6, "Expected " + expected + ", got " + actual);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
