package tests;

import common.MSMInstance;
import common.SolutionIO;
import common.VRPTWInstance;
import common.read_in;
import common.read_in_MTVRPTW_msm;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;

/** 无求解器依赖的数据/解文件回归检查，从项目根目录运行。 */
public final class CommonDataTest {
    private static int checks;

    private CommonDataTest() {
    }

    public static void main(String[] args) throws Exception {
        Path temp = Files.createTempDirectory("chapter10-data-test-");
        try {
            checkRealInstances();
            checkParsing(temp);
            checkDistances(temp);
            checkSolutions(temp);
            System.out.println("CommonDataTest: " + checks + " checks passed.");
        } finally {
            try (var paths = Files.walk(temp)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) {
                    Files.delete(path);
                }
            }
        }
    }

    private static void checkRealInstances() throws IOException {
        VRPTWInstance full = read_in.readSolomon("instances/C201.txt");
        check(full.customerCount == 100 && full.nodeCount == 102, "C201 must contain 100 customers.");
        check(full.capacity == 700 && full.vehicleCount == 100, "Read the supplied header without reinterpretation.");
        VRPTWInstance subset = read_in.readSolomon("instances/C201.txt", 25, false, true, false);
        check(subset.customerCount == 25 && subset.vehicleCount == 100, "Customer subset and vehicle count are independent.");
        check(subset.x[subset.end] == subset.x[0] && subset.service[subset.end] == 0,
                "Return depot must copy the departure coordinates.");
        MSMInstance msm = read_in_MTVRPTW_msm.readSolomonMSM(
                "instances/Solomon_2/C201.txt", 16, false, true, false);
        check(msm.base.customerCount == 16 && msm.staffTypes == 2, "Read the 16-customer MSM instance.");
        check(msm.staffRaw[0][9] == 2 && msm.staffRaw[1][9] == 1 && msm.base.ready[9] == 2601,
                "Staff columns must not shift the time-window columns.");
        try (var paths = Files.walk(Path.of("instances"))) {
            for (Path path : paths.filter(p -> p.toString().endsWith(".txt")).toList()) {
                if (path.getParent().getFileName().toString().equals("Solomon_2")) {
                    read_in_MTVRPTW_msm.readSolomonMSM(path.toString(), 0, false, true, false);
                } else {
                    read_in.readSolomon(path.toString());
                }
                check(true, "Parse " + path);
            }
        }
    }

    private static void checkParsing(Path temp) throws IOException {
        String rows = "0 0 0 0 0 100 0\n1 1 0 1 0 100 0\n2 2 0 1 0 100 0\n";
        Path valid = write(temp, "valid.txt", standard(rows));
        check(read_in.readSolomon(valid.toString()).customerCount == 2,
                "A one-vehicle header must not truncate two customers.");
        expectFailure(temp, "missing.txt", standard(rows.replace("1 1 0 1 0 100 0\n", "")), false);
        expectFailure(temp, "duplicate.txt", standard(rows + "1 1 0 1 0 100 0\n"), false);
        expectFailure(temp, "bad-window.txt", standard(rows.replace("1 1 0 1 0 100 0", "1 1 0 1 101 100 0")), false);
        expectFailure(temp, "bad-field.txt", standard(rows.replace("1 1 0 1 0 100 0", "1 1x 0 1 0 100 0")), false);
        expectFailure(temp, "fractional-id.txt", standard(rows.replace("1 1 0 1 0 100 0", "1.5 1 0 1 0 100 0")), false);
        expectFailure(temp, "staff-negative.txt", "MSM\nVEHICLE\n16\nCUSTOMER\n"
                + "0 0 0 0 0 0 100 0\n1 1 0 1 -1 0 100 0\n", true);
        expectFailure(temp, "staff-columns.txt", "MSM\nVEHICLE\n16\nCUSTOMER\n"
                + "0 0 0 0 0 0 100 0\n1 1 0 1 1 0 0 100 0\n", true);
    }

    private static void checkDistances(Path temp) throws IOException {
        Path path = write(temp, "distance.txt", standard(
                "0 0 0 0 0 100 0\n1 1.49 0 1 0 100 0\n"));
        near(read_in.readSolomon(path.toString(), false, false, false).distance[0][1], 1.49);
        near(read_in.readSolomon(path.toString(), false, true, false).distance[0][1], 1.5);
        near(read_in.readSolomon(path.toString(), false, true, true).distance[0][1], 1.4);
        Path closure = write(temp, "closure.txt", standard(
                "0 0 0 0 0 100 0\n1 0.14 0 1 0 100 0\n2 0.28 0 1 0 100 0\n"));
        near(read_in.readSolomon(closure.toString(), false, true, false).distance[0][2], 0.3);
        VRPTWInstance closed = read_in.readSolomon(closure.toString(), true, true, false);
        near(closed.distance[0][2], 0.2);
        near(closed.travelTime[0][2], 0.2);
    }

    private static void checkSolutions(Path temp) throws IOException {
        Path path = temp.resolve("solution.txt");
        SolutionIO.writeSolution(path.toString(), "instances/C201.txt", "中文实例", "test",
                12.5, 12.0, 0.04, 0.2, "9", List.of(
                        "route 1: 0 1 0", "trip k=2 v=1: 0 2 0", "schedule k=2 departure=0 return=10"));
        SolutionIO.SolutionData solution = SolutionIO.readSolution(path.toString());
        check(solution.routes.equals(List.of(List.of(0, 1, 0), List.of(0, 2, 0))),
                "Parse route/trip lines and do not treat routes: count as a route.");
        check(solution.instanceName.equals("中文实例") && solution.status.equals("9"),
                "Preserve UTF-8 text and solve status.");
        SolutionIO.writeNoSolution(path.toString(), "instances/C201.txt", "中文实例", "test", "3", 0.4);
        SolutionIO.SolutionData noSolution = SolutionIO.readSolution(path.toString());
        check(noSolution.objective == null && noSolution.routes.isEmpty()
                && noSolution.status.equals("3") && noSolution.solveTime == 0.4,
                "No-solution result must replace the previous objective, status and routes.");
        check(noSolution.lowerBound == null && noSolution.gap == null
                && !Files.readString(path, StandardCharsets.UTF_8).contains("objective:"),
                "No-solution result must omit previous optimization values.");
        Path invalid = write(temp, "bad-solution.txt", "routes: 2\nroute 1: 0 1 0\n");
        try {
            SolutionIO.readSolution(invalid.toString());
            throw new AssertionError("Inconsistent route count must be rejected.");
        } catch (IOException expected) {
            checks++;
        }
    }

    private static String standard(String rows) {
        return "TEST\nVEHICLE\nNUMBER CAPACITY\n1 10\nCUSTOMER\n"
                + "CUST NO. X Y DEMAND READY DUE SERVICE\n" + rows;
    }

    private static Path write(Path temp, String name, String text) throws IOException {
        return Files.writeString(temp.resolve(name), text, StandardCharsets.UTF_8);
    }

    private static void expectFailure(Path temp, String name, String content, boolean msm) throws IOException {
        Path path = write(temp, name, content);
        try {
            if (msm) {
                read_in_MTVRPTW_msm.readSolomonMSM(path.toString(), 0, false, true, false);
            } else {
                read_in.readSolomon(path.toString());
            }
            throw new AssertionError("Invalid input was accepted: " + name);
        } catch (IOException expected) {
            checks++;
        }
    }

    private static void near(double actual, double expected) {
        check(Math.abs(actual - expected) < 1e-9, "Expected " + expected + ", got " + actual);
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
        checks++;
    }
}
