param(
    [ValidateSet('Gurobi', 'Copt', 'All')]
    [string]$Solver = 'All'
)
$ErrorActionPreference = 'Stop'
& "$PSScriptRoot/build.ps1" -Solver $Solver
$classes = Join-Path $PSScriptRoot 'build/classes'
& javac '-J-Dfile.encoding=UTF-8' --release 21 -encoding UTF-8 -cp $classes -d $classes "$PSScriptRoot/tests/SolverResultTest.java"
if ($LASTEXITCODE -ne 0) { throw 'Result-test compilation failed.' }
$logDir = Join-Path $PSScriptRoot 'build/smoke-logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$solvers = if ($Solver -eq 'All') { @('Gurobi', 'Copt') } else { @($Solver) }

function Invoke-Case([string]$ModelClass, [string[]]$ModelArgs, [string]$CaseName) {
    $log = Join-Path $logDir "$CaseName.log"
    & "$PSScriptRoot/run.ps1" -NoBuild -Class $ModelClass -Arguments $ModelArgs *> $log
    Write-Host "Solved $CaseName (log: $log)"
}

Push-Location -LiteralPath $PSScriptRoot
try {
    foreach ($suffix in $solvers) {
        Invoke-Case "vrptw.VRPTW_$suffix" @('tests/fixtures/tiny-vrptw.txt', '10', '4', '0') "vrptw-$suffix"
        Invoke-Case "sdvrptwl.SDVRPTWL_$suffix" @('tests/fixtures/tiny-vrptw.txt', '10', '4', '0') "sd-$suffix"
        Invoke-Case "mtvrptw.MTVRPTW_$suffix" @('tests/fixtures/tiny-vrptw.txt', '10', '2', '0') "multi-trip-$suffix"
        Invoke-Case "mtvrptwmsm.MTVRPTW_MSM_$suffix" @('tests/fixtures/tiny-msm.txt', '10', '1', '0', '3') "msm-$suffix"
        Invoke-Case "sdvrptwl.SDVRPTWL_$suffix" @('tests/fixtures/tiny-split.txt', '10', '4', '0') "split-$suffix"
        Invoke-Case "mtvrptwmsm.MTVRPTW_MSM_$suffix" @('tests/fixtures/tiny-msm-four-staff.txt', '10', '1', '0', '1') "four-staff-$suffix"
        Invoke-Case "mtvrptwmsm.MTVRPTW_MSM_$suffix" @('tests/fixtures/tiny-msm-two-trips.txt', '10', '1', '0', '3') "two-trips-$suffix"
        Invoke-Case "mtvrptwmsm.MTVRPTW_MSM_$suffix" @('tests/fixtures/tiny-msm-late-only.txt', '10', '1', '0', '1') "late-only-$suffix"
        Invoke-Case "mtvrptwmsm.MTVRPTW_MSM_$suffix" @('tests/fixtures/tiny-msm-fleet-required.txt', '10', '2', '0', '1') "fleet-required-$suffix"
        Invoke-Case "mtvrptwmsm.MTVRPTW_MSM_$suffix" @('tests/fixtures/tiny-msm-return-lunch.txt', '10', '1', '0', '3') "return-lunch-$suffix"
        & java '-Dfile.encoding=UTF-8' -cp $classes tests.SolverResultTest $suffix
        if ($LASTEXITCODE -ne 0) { throw "Result verification failed: $suffix" }

        $log = Join-Path $logDir "zero-service-$suffix.log"
        try {
            & "$PSScriptRoot/run.ps1" -NoBuild -Class "vrptw.VRPTW_$suffix" -Arguments @(
                'tests/fixtures/zero-service-cycle.txt', '10', '4', '0') *> $log
        } catch {
            if ((Get-Content -LiteralPath $log -Raw) -notmatch 'positive service time') { throw }
        }
        if ((Get-Content -LiteralPath $log -Raw) -notmatch 'positive service time') {
            throw 'Zero-service input should have been rejected.'
        }
        Write-Host "Rejected unsupported zero-service input ($suffix)."
    }
} finally { Pop-Location }
