param(
    [ValidateSet('None', 'Gurobi', 'Copt', 'All')]
    [string]$Solver = 'All'
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/scripts/solver-env.ps1"

$selected = switch ($Solver) {
    'All' { @('Gurobi', 'Copt') }
    'None' { @() }
    default { @($Solver) }
}
$jars = @($selected | ForEach-Object { (Get-SolverConfig $_).Jar })
$sources = @(Get-ChildItem -LiteralPath "$PSScriptRoot/src" -Filter '*.java' -Recurse |
    Where-Object {
        ($_.Name -notmatch '(Gurobi|Copt|SimpleMIPExample)') -or
        ($selected -contains 'Gurobi' -and $_.Name -match 'Gurobi|SimpleMIPExample') -or
        ($selected -contains 'Copt' -and $_.Name -match 'Copt')
    } | ForEach-Object { $_.FullName })
$destination = Join-Path $PSScriptRoot 'build/classes'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
$compileArgs = @('-J-Dfile.encoding=UTF-8', '--release', '21', '-encoding', 'UTF-8', '-Xlint:all', '-d', $destination)
if ($jars.Count -gt 0) { $compileArgs += @('-cp', ($jars -join [IO.Path]::PathSeparator)) } else { $compileArgs += @('-cp', $destination) }
$compileArgs += $sources
& javac @compileArgs
if ($LASTEXITCODE -ne 0) { throw "javac failed (exit $LASTEXITCODE)." }
Write-Host "Compiled $($sources.Count) source files ($Solver)."
