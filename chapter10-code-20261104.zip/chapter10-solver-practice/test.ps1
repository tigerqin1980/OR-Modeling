$ErrorActionPreference = 'Stop'

# 默认检查仅依赖 JDK，不需要求解器 JAR、动态库或许可证。
$sources = @(Get-ChildItem -LiteralPath "$PSScriptRoot/src/common" -Filter '*.java' |
    ForEach-Object { $_.FullName })
$sources += Join-Path $PSScriptRoot 'tests/CommonDataTest.java'
$destination = Join-Path $PSScriptRoot 'build/test-classes'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
$compileArgs = @('-J-Dfile.encoding=UTF-8', '--release', '21', '-encoding', 'UTF-8',
    '-Xlint:all', '-cp', $destination, '-d', $destination) + $sources
& javac @compileArgs
if ($LASTEXITCODE -ne 0) { throw "Test compilation failed (exit $LASTEXITCODE)." }

Push-Location -LiteralPath $PSScriptRoot
try {
    & java '-Dfile.encoding=UTF-8' -cp $destination tests.CommonDataTest
    if ($LASTEXITCODE -ne 0) { throw "CommonDataTest failed (exit $LASTEXITCODE)." }
} finally { Pop-Location }
