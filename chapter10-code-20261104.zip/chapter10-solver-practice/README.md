# 第10章：整数规划求解器实践

配套 Java 教学代码，包含 Gurobi 与 COPT 两种实现。代码按“读数据 → 建变量 → 加约束 → 求解 → 检查状态 → 输出结果”组织，保留书中的主类名称，方便逐段对照。

书稿对应关系见 [核对说明](docs/book-code-alignment.md)，实测结果见 [验证记录](docs/verification.md)。

## 环境

| 组件 | 本次验证版本 |
| --- | --- |
| JDK | 21.0.9，编译目标 Java 21 |
| Gurobi | 12.0.3 |
| COPT | 8.0.2，使用8.0系列 Java MIP接口 |
| 运行脚本 | PowerShell；已在 Windows 验证 |

只使用一种求解器时，只需安装对应的 Java 库、动态库和有效许可证。库文件使用安装目录中的版本，不随仓库分发。

## 快速运行

在项目根目录打开 PowerShell。先按自己的安装位置设置环境变量，指向包含 `lib` 和 `bin` 的目录：

```powershell
$env:GUROBI_HOME = 'D:/gurobi/win64'
$env:COPT_HOME = 'D:/COPT/copt80'

# 只编译所选求解器，或用 All 编译两种实现
./build.ps1 -Solver Copt

# 小算例：3个客户，最优总距离为6
./run.ps1 vrptw.VRPTW_Copt tests/fixtures/tiny-vrptw.txt 10 4 0

# 书中C201：100客户、最多4辆车；这里将时限缩短为60秒
./run.ps1 vrptw.VRPTW_Copt instances/C201.txt 60 4

# 使用Gurobi时替换类名后缀
./run.ps1 vrptw.VRPTW_Gurobi instances/C201.txt 60 4
```

`run.ps1` 自动编译对应源码、临时配置动态库路径，并从项目根目录运行。已编译时可加 `-NoBuild`。求解器报错会返回失败；正常限时结束后须查看结果中的状态和间隙。

## 书中三个案例

| 案例 | Gurobi主类 | COPT主类 | 默认客户数 / 容量 / 车辆数参数 |
| --- | --- | --- | --- |
| VRPTW | `vrptw.VRPTW_Gurobi` | `vrptw.VRPTW_Copt` | 全部100 / 文件值700 / 4 |
| SDVRPTWL | `sdvrptwl.SDVRPTWL_Gurobi` | `sdvrptwl.SDVRPTWL_Copt` | 前25 / 30 / 20 |
| MTVRPTW-MSM | `mtvrptwmsm.MTVRPTW_MSM_Gurobi` | `mtvrptwmsm.MTVRPTW_MSM_Copt` | 前16 / 12 / 2 |

默认时限均为3600秒。前两个案例默认输入为 `instances/C201.txt`，MSM为 `instances/Solomon_2/C201.txt`。

命令行位置参数依次为：

```text
主类 [实例路径] [时限秒] [车辆数参数] [客户数] [MSM行程上限]
```

时限0表示不限制；客户数0表示全部。客户截取数与文件中的车辆数量相互独立。MSM默认行程上限6，该参数必须为正；16客户时可传16放宽到客户数。其他模型没有第5个参数。主类支持 `--help`。

```powershell
./run.ps1 sdvrptwl.SDVRPTWL_Copt instances/C201.txt 60 20 25
./run.ps1 mtvrptwmsm.MTVRPTW_MSM_Copt instances/Solomon_2/C201.txt 60 2 16 6
```

VRPTW、SD以及额外的MTVRPTW示例可用车辆参数-1采用文件值；MSM必须指定正车辆数，因为派生数据文件头不能用于推断实际车辆数。

## 输入与模型约定

标准输入每个客户有7列：

```text
id x y demand ready due service
```

本例MSM输入有9列：

```text
id x y demand staff_0 staff_1 ready due service
```

MSM的 `staff_0` 为低技能需求，`staff_1` 为高技能需求。模型内部等级1为高技能、等级2为低技能，可用人数分别1、3，每趟费用分别45、40。人员变量为累计人数，费用按累计人数的差分计入目标。

VRPTW使用原始欧氏距离；SD和MSM先向下截断一位小数，再计算度量闭包。旅行时间与处理后的距离数值相同。SD默认载重成本系数0、距离成本系数1。

这些教学模型要求所有客户的服务时间为正，通过时间递推排除客户子环；不支持的数据会在建模前明确报错。通用读取器仍允许零服务时间，扩展模型时需自行补充连通性约束。

MSM以原论文补充材料Appendix A为模型基准（来源见[原始附件](docs/paper-source.md)）。车辆参数表示给定车辆数：按A.11，每辆给定车辆都必须执行行程并安排一次午休；VRPTW和SD的对应参数仍是车辆上限。MSM没有eta或全天固定班组约束。午休窗口为仓库最晚返回时刻的40%至60%，时长为10%；被选行程不晚于窗口下界出发，在窗口内返回。车辆和人员接续分别按A.16、A.19计入午休。t_min只属于正文的集合覆盖算法。A.7作等价线性化，大M按变量时间窗推导，详见[公式映射](docs/book-code-alignment.md)。

数据按只读使用；`VRPTWInstance` 的公开数组不是深度不可变对象。数据来源与派生情况见 [数据说明](instances/README.md)。

## 输出

结果写入 `solutions/<输入文件名>_<模型与求解器>.txt`，重复运行同名实例会覆盖该文件：

- 有解：保存求解状态、目标值、下界、相对间隙、耗时与路线。
- 无解或限时尚无可行解：只保存状态、耗时及 `routes: 0`，清除上次运行的旧解。
- SD另有 `delivery` 行，记录车辆给客户的实际送货量。
- MSM另有 `schedule` 行，记录行程起止时间、累计人数、工作人员编号及午休车辆。

限时可行解的目标值不能视作最优值。`gap` 用小数表示，例如0.0442约为4.42%。本版本COPT最优状态为1、限时为8；Gurobi最优为2、限时为9。

绘制路线图：

```powershell
./run.ps1 visual.VRPTW_SolutionPlot solutions/C201_VRPTW_Copt.txt
```

默认在同目录生成PNG，也支持SD和MSM的客户子集。追加输出路径可另存，追加 `--show` 可打开窗口。

## 检查与参考结果

```powershell
# 无需求解器：数据读取、预处理、解文件读写
./test.ps1

# 需要对应的有效许可证：10个回归算例及零服务时间输入防护
./smoke-test.ps1 -Solver Copt
./smoke-test.ps1 -Solver Gurobi
```

GitHub Actions只运行无需求解器的编译和数据检查。完整求解检查在具备许可证的本地环境运行。

参考目标值：小型VRPTW和SD均为6；必须拆分的单客户例为4；MSM三客户例为91；需要4名工作人员的单客户例为167；两趟且共用一名高技能人员例为94；仅下午行程例按A.11和A.25应不可行；两辆给定车辆但仅一个候选行程也应不可行。输入与预期值见 [参考结果表](examples/expected-results.csv)，本机结果见 [验证记录](docs/verification.md)。

## 目录

```text
src/common/       数据、预处理、输入检查与结果读写
src/vrptw/        10.7.1：VRPTW两种求解器实现
src/sdvrptwl/     10.7.2：拆分配送两种实现
src/mtvrptwmsm/   10.7.3：多技能多行程两种实现
src/examples/    10.5空气污染LP、10.6饮食LP
src/mtvrptw/      补充：带仓库卸货时隙的多行程模型
src/visual/       路线绘图
instances/        配套输入数据
tests/            自检代码与可手算数据
examples/         参考结果
docs/             书稿核对与验证记录
```

保留 `read_in`、`read_in_MTVRPTW_msm` 等教材类名作为兼容入口；统一解析实现在 `SolomonReader` 中。`SimpleMIPExample` 是额外的最小Gurobi例，理论最优值8。

源码、数据和说明可直接放入GitHub；生成目录、求解日志、求解器库与许可证已通过 `.gitignore` 排除。仓库未代作者选择开源许可证。
