package examples;

import copt.Consts;
import copt.DblAttr;
import copt.DblInfo;
import copt.Envr;
import copt.Expr;
import copt.IntAttr;
import copt.Model;
import copt.Var;

/** 第10.6节饮食LP，使用COPT 8.0系列 Java API。 */
public final class DietCopt {
    private static final int LP_OPTIMAL = 1; // COPT 8.0 LP状态码：最优。
    private DietCopt() {}

    public static void main(String[] args) throws Exception {
        Envr env = new Envr();
        Model model = null;
        try {
            model = env.createModel("Diet");
            Var beef = model.addVar(0, 1000, 0, Consts.CONTINUOUS, "Beef");
            Var chicken = model.addVar(0, 1000, 0, Consts.CONTINUOUS, "Chicken");
            Var fish = model.addVar(0, 1000, 0, Consts.CONTINUOUS, "Fish");
            Expr objective = new Expr();
            objective.addTerm(beef, 3.19);
            objective.addTerm(chicken, 2.59);
            objective.addTerm(fish, 2.29);
            model.setObjective(objective, Consts.MINIMIZE);
            Expr vitaminA = new Expr();
            vitaminA.addTerm(beef, 60);
            vitaminA.addTerm(chicken, 8);
            vitaminA.addTerm(fish, 8);
            model.addConstr(vitaminA, Consts.GREATER_EQUAL, 700, "vitA");
            Expr vitaminC = new Expr();
            vitaminC.addTerm(beef, 20);
            vitaminC.addTerm(fish, 10);
            model.addConstr(vitaminC, Consts.GREATER_EQUAL, 700, "vitC");
            model.solve();
            int status = model.getIntAttr(IntAttr.LpStatus);
            System.out.println("LP status = " + status);
            if (status == LP_OPTIMAL) {
                System.out.println("Objective = " + model.getDblAttr(DblAttr.LpObjVal));
                System.out.printf("Beef=%s, Chicken=%s, Fish=%s%n",
                        beef.get(DblInfo.Value), chicken.get(DblInfo.Value), fish.get(DblInfo.Value));
            }
        } finally {
            try {
                if (model != null) model.dispose();
            } finally {
                env.dispose();
            }
        }
    }
}
