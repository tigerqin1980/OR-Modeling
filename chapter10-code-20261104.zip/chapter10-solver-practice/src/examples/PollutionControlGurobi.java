package examples;

import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBConstr;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

/** 第10.5节空气污染控制LP；仅在LP最优时读取对偶值。 */
public final class PollutionControlGurobi {
    private PollutionControlGurobi() {}

    public static void main(String[] args) throws Exception {
        double[] cost = {8, 10, 7, 6, 11, 9};
        double[][] coefficients = {
            {12, 9, 25, 20, 17, 13},
            {35, 42, 18, 31, 56, 49},
            {37, 53, 28, 24, 29, 20}
        };
        double[] minimum = {60, 150, 125};
        GRBEnv env = new GRBEnv();
        GRBModel model = null;
        try {
            model = new GRBModel(env);
            GRBVar[] x = new GRBVar[cost.length];
            GRBLinExpr objective = new GRBLinExpr();
            for (int j = 0; j < x.length; j++) {
                x[j] = model.addVar(0, 1, 0, GRB.CONTINUOUS, "x_" + (j + 1));
                objective.addTerm(cost[j], x[j]);
            }
            model.setObjective(objective, GRB.MINIMIZE);
            GRBConstr[] constraints = new GRBConstr[minimum.length];
            for (int i = 0; i < minimum.length; i++) {
                GRBLinExpr row = new GRBLinExpr();
                for (int j = 0; j < x.length; j++) row.addTerm(coefficients[i][j], x[j]);
                constraints[i] = model.addConstr(row, GRB.GREATER_EQUAL, minimum[i], "minimum_" + i);
            }
            model.optimize();
            int status = model.get(GRB.IntAttr.Status);
            System.out.println("Status = " + status);
            if (model.get(GRB.IntAttr.SolCount) > 0) {
                System.out.println("Objective = " + model.get(GRB.DoubleAttr.ObjVal));
                for (GRBVar variable : x) {
                    System.out.println(variable.get(GRB.StringAttr.VarName) + " = "
                            + variable.get(GRB.DoubleAttr.X));
                }
            }
            if (status == GRB.OPTIMAL) {
                for (GRBConstr constraint : constraints) {
                    System.out.println(constraint.get(GRB.StringAttr.ConstrName) + " dual = "
                            + constraint.get(GRB.DoubleAttr.Pi));
                }
            }
        } finally {
            try {
                if (model != null) model.dispose();
            } finally {
                env.dispose();
            }
        }
    }
}
