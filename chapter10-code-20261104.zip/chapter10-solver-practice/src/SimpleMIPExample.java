import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;

/** 最小混合整数规划示例：最优值为 8，x=4，y=z=0。 */
public final class SimpleMIPExample {
    private SimpleMIPExample() {}

    public static void main(String[] args) throws Exception {
        GRBEnv env = new GRBEnv();
        GRBModel model = null;
        try {
            model = new GRBModel(env);
            model.set(GRB.StringAttr.ModelName, "SimpleMIP");
            GRBVar x = model.addVar(0, GRB.INFINITY, 0, GRB.INTEGER, "x");
            GRBVar y = model.addVar(0, GRB.INFINITY, 0, GRB.INTEGER, "y");
            GRBVar z = model.addVar(0, GRB.INFINITY, 0, GRB.CONTINUOUS, "z");

            GRBLinExpr objective = new GRBLinExpr();
            objective.addTerm(2, x);
            objective.addTerm(3, y);
            objective.addTerm(1, z);
            model.setObjective(objective, GRB.MAXIMIZE);

            GRBLinExpr resource = new GRBLinExpr();
            resource.addTerm(1, x);
            resource.addTerm(2, y);
            resource.addTerm(1, z);
            model.addConstr(resource, GRB.LESS_EQUAL, 4, "resource");
            GRBLinExpr minimum = new GRBLinExpr();
            minimum.addTerm(1, x);
            minimum.addTerm(1, y);
            model.addConstr(minimum, GRB.GREATER_EQUAL, 1, "minimum");

            model.optimize();
            int status = model.get(GRB.IntAttr.Status);
            System.out.println("Status = " + status);
            if (model.get(GRB.IntAttr.SolCount) > 0) {
                System.out.println("Objective = " + model.get(GRB.DoubleAttr.ObjVal));
                System.out.printf("x=%s, y=%s, z=%s%n",
                        x.get(GRB.DoubleAttr.X), y.get(GRB.DoubleAttr.X), z.get(GRB.DoubleAttr.X));
            }
        } finally {
            try {
                if (model != null) model.dispose();
            } finally {
                env.dispose();
            }
        }
    }
}
