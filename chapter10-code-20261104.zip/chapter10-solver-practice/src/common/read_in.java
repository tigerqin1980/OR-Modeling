package common;

import java.io.IOException;

/** 书稿中的兼容入口；实际解析与校验由 {@link SolomonReader} 完成。 */
public final class read_in {
    private read_in() {
    }

    public static VRPTWInstance readSolomon(String path) throws IOException {
        return readSolomon(path, false);
    }

    public static VRPTWInstance readSolomon(String path, boolean applyMetricClosure) throws IOException {
        return readSolomon(path, applyMetricClosure, true);
    }

    public static VRPTWInstance readSolomon(
            String path, boolean applyMetricClosure, boolean applyRounding) throws IOException {
        return readSolomon(path, applyMetricClosure, applyRounding, false);
    }

    public static VRPTWInstance readSolomon(
            String path, boolean applyMetricClosure, boolean applyRounding,
            boolean applyTruncation) throws IOException {
        return readSolomon(path, 0, applyMetricClosure, applyRounding, applyTruncation);
    }

    /** customerLimit 为 0 时读取全部客户；车辆数不影响客户截取。 */
    public static VRPTWInstance readSolomon(
            String path, int customerLimit, boolean applyMetricClosure,
            boolean applyRounding, boolean applyTruncation) throws IOException {
        return SolomonReader.read(path, customerLimit, applyMetricClosure, applyRounding, applyTruncation);
    }
}
