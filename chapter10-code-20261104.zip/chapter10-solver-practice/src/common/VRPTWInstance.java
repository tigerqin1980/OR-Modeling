package common;

/**
 * 起点为 0、客户为 1..customerCount、终点为 customerCount+1 的实例数据。
 * 字段引用固定；数组为教学代码直接访问，应由调用方按只读数据使用。
 */
public final class VRPTWInstance {
    public final String name;
    public final int vehicleCount;
    public final double capacity;
    public final int customerCount;
    public final int nodeCount;
    public final int start;
    public final int end;
    public final double[] x;
    public final double[] y;
    public final double[] demand;
    public final double[] ready;
    public final double[] due;
    public final double[] service;
    public final double[][] distance;
    public final double[][] travelTime;

    public VRPTWInstance(
            String name,
            int vehicleCount,
            double capacity,
            int customerCount,
            int nodeCount,
            int start,
            int end,
            double[] x,
            double[] y,
            double[] demand,
            double[] ready,
            double[] due,
            double[] service,
            double[][] distance,
            double[][] travelTime) {
        this.name = name;
        this.vehicleCount = vehicleCount;
        this.capacity = capacity;
        this.customerCount = customerCount;
        this.nodeCount = nodeCount;
        this.start = start;
        this.end = end;
        this.x = x;
        this.y = y;
        this.demand = demand;
        this.ready = ready;
        this.due = due;
        this.service = service;
        this.distance = distance;
        this.travelTime = travelTime;
    }
}
