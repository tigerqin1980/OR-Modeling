package common;

/** 原始工作人员需求列按文件中的顺序保存，累计技能需求在建模阶段计算。 */
public final class MSMInstance {
    public final VRPTWInstance base;
    public final int staffTypes;
    public final int[][] staffRaw;

    public MSMInstance(VRPTWInstance base, int staffTypes, int[][] staffRaw) {
        this.base = base;
        this.staffTypes = staffTypes;
        this.staffRaw = staffRaw;
    }
}
