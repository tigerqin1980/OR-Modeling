package common;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;

/**
 * 读取 UTF-8 Solomon 数据，检查缺号、重复编号和字段错误。
 * 距离处理顺序为欧氏距离、一位小数处理（可选）、Floyd 度量闭包（可选）。
 * 旅行时间与处理后的距离数值相同，车速视为 1。
 */
public final class SolomonReader {
    private SolomonReader() {
    }

    /** customerLimit=0 表示全部客户；其他值表示前 customerLimit 个客户。 */
    public static VRPTWInstance read(
            String path, int customerLimit, boolean metricClosure,
            boolean rounding, boolean truncation) throws IOException {
        return parse(path, customerLimit, metricClosure, rounding, truncation, false).base;
    }

    /** MSM 每行格式为 id x y demand staff_0 ... staff_m ready due service。 */
    public static MSMInstance readMSM(
            String path, int customerLimit, boolean metricClosure,
            boolean rounding, boolean truncation) throws IOException {
        return parse(path, customerLimit, metricClosure, rounding, truncation, true);
    }

    private static MSMInstance parse(
            String path, int customerLimit, boolean metricClosure,
            boolean rounding, boolean truncation, boolean msm) throws IOException {
        if (customerLimit < 0) {
            throw new IllegalArgumentException("customerLimit must be nonnegative (0 means all customers).");
        }
        String name = null;
        int vehicleCount = 0;
        double capacity = 0.0;
        int staffTypes = -1;
        int section = 0;
        Map<Integer, double[]> rows = new TreeMap<>();
        try (BufferedReader reader = Files.newBufferedReader(Path.of(path), StandardCharsets.UTF_8)) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                line = line.replace("\uFEFF", "").trim();
                if (line.isEmpty()) {
                    continue;
                }
                if (name == null) {
                    name = line;
                } else if (line.equals("VEHICLE")) {
                    section = 1;
                } else if (line.equals("CUSTOMER")) {
                    section = 2;
                } else if (Character.isDigit(line.charAt(0)) || line.charAt(0) == '-'
                        || line.charAt(0) == '+' || line.charAt(0) == '.') {
                    double[] values = numbers(line, path, lineNumber);
                    if (section == 1) {
                        if (values.length != 2 && !(msm && values.length == 1)) {
                            throw invalid(path, lineNumber, "Expected vehicle number and capacity.");
                        }
                        vehicleCount = integer(values[0], path, lineNumber, "vehicle number");
                        capacity = values.length == 2 ? values[1] : 0.0;
                        if (vehicleCount <= 0 || (values.length == 2 && capacity <= 0)) {
                            throw invalid(path, lineNumber, "Vehicle number and capacity must be positive.");
                        }
                        section = 0;
                    } else if (section == 2) {
                        int columns = values.length - 7;
                        if ((!msm && columns != 0) || (msm && columns < 1)) {
                            throw invalid(path, lineNumber, "Unexpected customer field count.");
                        }
                        if (staffTypes >= 0 && staffTypes != columns) {
                            throw invalid(path, lineNumber, "Inconsistent staff field count.");
                        }
                        staffTypes = columns;
                        int id = integer(values[0], path, lineNumber, "customer id");
                        if (id < 0 || rows.putIfAbsent(id, values) != null) {
                            throw invalid(path, lineNumber, "Negative or duplicate customer id: " + id);
                        }
                        for (int s = 0; s < columns; s++) {
                            if (integer(values[4 + s], path, lineNumber, "staff demand") < 0) {
                                throw invalid(path, lineNumber, "Staff demand must be nonnegative.");
                            }
                        }
                        int ready = values.length - 3;
                        if (values[3] < 0 || values[ready] < 0 || values[ready] > values[ready + 1]
                                || values[ready + 2] < 0) {
                            throw invalid(path, lineNumber, "Invalid demand, time window or service time.");
                        }
                    } else {
                        throw invalid(path, lineNumber, "Numeric data outside VEHICLE/CUSTOMER section.");
                    }
                }
            }
        }
        if (name == null || vehicleCount == 0 || rows.size() < 2 || !rows.containsKey(0)) {
            throw new IOException("Incomplete Solomon instance: " + path);
        }
        int fullCustomerCount = rows.size() - 1;
        for (int id = 0; id <= fullCustomerCount; id++) {
            if (!rows.containsKey(id)) {
                throw new IOException("Missing customer id " + id + " in " + path);
            }
        }
        if (customerLimit > fullCustomerCount) {
            throw new IOException("Requested " + customerLimit + " customers, but file has "
                    + fullCustomerCount + ": " + path);
        }
        int n = customerLimit == 0 ? fullCustomerCount : customerLimit;
        int end = n + 1;
        int nodeCount = n + 2;
        double[] x = new double[nodeCount];
        double[] y = new double[nodeCount];
        double[] demand = new double[nodeCount];
        double[] ready = new double[nodeCount];
        double[] due = new double[nodeCount];
        double[] service = new double[nodeCount];
        int[][] staff = new int[staffTypes][nodeCount];
        for (int i = 0; i <= n; i++) {
            double[] row = rows.get(i);
            x[i] = row[1];
            y[i] = row[2];
            demand[i] = row[3];
            for (int s = 0; s < staffTypes; s++) {
                staff[s][i] = (int) row[4 + s];
            }
            ready[i] = row[row.length - 3];
            due[i] = row[row.length - 2];
            service[i] = row[row.length - 1];
        }
        x[end] = x[0];
        y[end] = y[0];
        ready[end] = ready[0];
        due[end] = due[0];
        double[][] distance = new double[nodeCount][nodeCount];
        for (int i = 0; i < nodeCount; i++) {
            for (int j = 0; j < nodeCount; j++) {
                double value = Math.hypot(x[i] - x[j], y[i] - y[j]);
                // truncation 仅在 rounding=true 时启用；否则保留原始欧氏距离。
                if (rounding) {
                    value = (truncation ? Math.floor(value * 10.0) : Math.round(value * 10.0)) / 10.0;
                }
                distance[i][j] = value;
            }
        }
        if (metricClosure) {
            for (int k = 0; k < nodeCount; k++) {
                for (int i = 0; i < nodeCount; i++) {
                    for (int j = 0; j < nodeCount; j++) {
                        distance[i][j] = Math.min(distance[i][j], distance[i][k] + distance[k][j]);
                    }
                }
            }
        }
        double[][] travelTime = new double[nodeCount][];
        for (int i = 0; i < nodeCount; i++) {
            travelTime[i] = distance[i].clone();
        }
        VRPTWInstance base = new VRPTWInstance(name, vehicleCount, capacity, n, nodeCount, 0, end,
                x, y, demand, ready, due, service, distance, travelTime);
        return new MSMInstance(base, staffTypes, staff);
    }

    private static double[] numbers(String line, String path, int lineNumber) throws IOException {
        String[] fields = line.split("\\s+");
        double[] values = new double[fields.length];
        for (int i = 0; i < fields.length; i++) {
            try {
                values[i] = Double.parseDouble(fields[i]);
                if (!Double.isFinite(values[i])) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException exception) {
                throw invalid(path, lineNumber, "Invalid number: " + fields[i]);
            }
        }
        return values;
    }

    private static int integer(double value, String path, int lineNumber, String field) throws IOException {
        if (value != Math.rint(value) || value < Integer.MIN_VALUE || value > Integer.MAX_VALUE) {
            throw invalid(path, lineNumber, "Expected integer " + field + ": " + value);
        }
        return (int) value;
    }

    private static IOException invalid(String path, int lineNumber, String message) {
        return new IOException(path + ":" + lineNumber + ": " + message);
    }
}
