package common;

/** 教学模型的适用条件；通用数据读取器不受这些条件限制。 */
public final class SolverChecks {
    private SolverChecks() {
    }

    public static void requirePositiveServiceTimes(VRPTWInstance instance) {
        for (int customer = 1; customer <= instance.customerCount; customer++) {
            if (!(instance.service[customer] > 0.0)) {
                throw new IllegalArgumentException(
                        "This teaching solver requires a positive service time at every customer "
                                + "to exclude subtours; customer " + customer
                                + " has service time " + instance.service[customer] + ".");
            }
        }
    }
}
