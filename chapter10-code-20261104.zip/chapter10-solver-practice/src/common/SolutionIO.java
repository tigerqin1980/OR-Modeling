package common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** UTF-8 解文件读写；route/trip 行存路线，其他行存元数据。 */
public final class SolutionIO {
    private static final Pattern ROUTE_LINE = Pattern.compile("(?:route\\b|trip\\b).*:.*");

    private SolutionIO() {
    }

    public static String buildSolutionPath(String instancePath, String solverName) {
        String name = Path.of(instancePath).getFileName().toString();
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            name = name.substring(0, dot);
        }
        return Path.of("solutions", name + "_" + solverName + ".txt").toString();
    }

    public static void writeSolution(
            String outputPath, String instancePath, String instanceName,
            String solverName, double objective, List<String> routeLines) throws IOException {
        writeSolution(outputPath, instancePath, instanceName, solverName,
                objective, null, null, null, null, routeLines);
    }

    public static void writeSolution(
            String outputPath, String instancePath, String instanceName,
            String solverName, double objective, Double lowerBound, Double gap,
            Double solveTime, List<String> routeLines) throws IOException {
        writeSolution(outputPath, instancePath, instanceName, solverName,
                objective, lowerBound, gap, solveTime, null, routeLines);
    }

    /** status 为求解器原始状态码，限时获得的可行解仍可写出。 */
    public static void writeSolution(
            String outputPath, String instancePath, String instanceName,
            String solverName, double objective, Double lowerBound, Double gap,
            Double solveTime, String status, List<String> routeLines) throws IOException {
        if (!Double.isFinite(objective)) {
            throw new IllegalArgumentException("A solution objective must be finite.");
        }
        int routeCount = 0;
        for (String line : routeLines) {
            if (ROUTE_LINE.matcher(line).matches()) {
                parseRoute(line.substring(line.indexOf(':') + 1));
                routeCount++;
            }
        }
        Path output = Path.of(outputPath);
        Path parent = output.toAbsolutePath().getParent();
        Files.createDirectories(parent);
        try (BufferedWriter writer = Files.newBufferedWriter(output, StandardCharsets.UTF_8)) {
            line(writer, "instanceName", instanceName);
            line(writer, "instancePath", instancePath);
            line(writer, "solver", solverName);
            if (status != null) {
                line(writer, "status", status);
            }
            line(writer, "objective", objective);
            optionalNumber(writer, "lowerBound", lowerBound);
            optionalNumber(writer, "gap", gap);
            optionalNumber(writer, "solveTime", solveTime);
            line(writer, "routes", routeCount);
            for (String routeLine : routeLines) {
                writer.write(routeLine);
                writer.newLine();
            }
        }
    }

    /** 无可行解时覆盖旧结果，避免误用上次运行的目标值和路线。 */
    public static void writeNoSolution(
            String outputPath, String instancePath, String instanceName,
            String solverName, String status, double solveTime) throws IOException {
        Path output = Path.of(outputPath);
        Files.createDirectories(output.toAbsolutePath().getParent());
        try (BufferedWriter writer = Files.newBufferedWriter(output, StandardCharsets.UTF_8)) {
            line(writer, "instanceName", instanceName);
            line(writer, "instancePath", instancePath);
            line(writer, "solver", solverName);
            line(writer, "status", status);
            optionalNumber(writer, "solveTime", solveTime);
            line(writer, "routes", 0);
        }
    }

    public static SolutionData readSolution(String solutionPath) throws IOException {
        String instancePath = null;
        String instanceName = null;
        String solverName = null;
        String status = null;
        Double objective = null;
        Double lowerBound = null;
        Double gap = null;
        Double solveTime = null;
        Integer declaredRouteCount = null;
        List<List<Integer>> routes = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(Path.of(solutionPath), StandardCharsets.UTF_8)) {
            String text;
            int lineNumber = 0;
            while ((text = reader.readLine()) != null) {
                lineNumber++;
                text = text.trim();
                if (text.isEmpty() || text.startsWith("#")) {
                    continue;
                }
                int colon = text.indexOf(':');
                if (colon < 0) {
                    continue;
                }
                String key = text.substring(0, colon).trim();
                String value = text.substring(colon + 1).trim();
                try {
                    switch (key) {
                        case "instancePath": instancePath = value; break;
                        case "instanceName": instanceName = value; break;
                        case "solver": solverName = value; break;
                        case "status": status = value; break;
                        case "objective": objective = finite(value); break;
                        case "lowerBound": lowerBound = finite(value); break;
                        case "gap": gap = finite(value); break;
                        case "solveTime": solveTime = finite(value); break;
                        case "routes": declaredRouteCount = Integer.parseInt(value); break;
                        default:
                            if (ROUTE_LINE.matcher(text).matches()) {
                                routes.add(parseRoute(value));
                            }
                    }
                } catch (IllegalArgumentException exception) {
                    throw new IOException(solutionPath + ":" + lineNumber + ": " + exception.getMessage(), exception);
                }
            }
        }
        if (declaredRouteCount != null && declaredRouteCount != routes.size()) {
            throw new IOException("Declared route count differs from route lines: " + solutionPath);
        }
        return new SolutionData(instancePath, instanceName, solverName, objective,
                lowerBound, gap, solveTime, status, routes);
    }

    private static List<Integer> parseRoute(String text) {
        List<Integer> route = new ArrayList<>();
        for (String field : text.trim().split("\\s+")) {
            int node = Integer.parseInt(field);
            if (node < 0) {
                throw new IllegalArgumentException("Route nodes must be nonnegative.");
            }
            route.add(node);
        }
        if (route.size() < 2) {
            throw new IllegalArgumentException("A route requires departure and arrival nodes.");
        }
        return route;
    }

    private static double finite(String text) {
        double value = Double.parseDouble(text);
        if (!Double.isFinite(value)) {
            throw new IllegalArgumentException("Expected a finite number: " + text);
        }
        return value;
    }

    private static void optionalNumber(BufferedWriter writer, String key, Double value) throws IOException {
        if (value != null && Double.isFinite(value)) {
            line(writer, key, value);
        }
    }

    private static void line(BufferedWriter writer, String key, Object value) throws IOException {
        writer.write(key + ": " + value);
        writer.newLine();
    }

    public static final class SolutionData {
        public final String instancePath;
        public final String instanceName;
        public final String solverName;
        public final Double objective;
        public final Double lowerBound;
        public final Double gap;
        public final Double solveTime;
        public final String status;
        public final List<List<Integer>> routes;

        public SolutionData(
                String instancePath, String instanceName, String solverName, Double objective,
                Double lowerBound, Double gap, Double solveTime, String status, List<List<Integer>> routes) {
            this.instancePath = instancePath;
            this.instanceName = instanceName;
            this.solverName = solverName;
            this.objective = objective;
            this.lowerBound = lowerBound;
            this.gap = gap;
            this.solveTime = solveTime;
            this.status = status;
            this.routes = routes;
        }

        public SolutionData(
                String instancePath, String instanceName, String solverName, Double objective,
                Double lowerBound, Double gap, Double solveTime, List<List<Integer>> routes) {
            this(instancePath, instanceName, solverName, objective, lowerBound, gap, solveTime, null, routes);
        }

        public SolutionData(
                String instancePath, String instanceName, String solverName,
                Double objective, List<List<Integer>> routes) {
            this(instancePath, instanceName, solverName, objective, null, null, null, null, routes);
        }
    }
}
