package common;

import java.io.IOException;

/** 书稿中的 MSM 兼容入口；工作人员字段位于 demand 与 ready 之间。 */
public final class read_in_MTVRPTW_msm {
    private read_in_MTVRPTW_msm() {
    }

    public static MSMInstance readSolomonMSM(
            String path, int customerLimit, boolean applyMetricClosure,
            boolean applyRounding, boolean applyTruncation) throws IOException {
        return SolomonReader.readMSM(path, customerLimit, applyMetricClosure, applyRounding, applyTruncation);
    }
}
