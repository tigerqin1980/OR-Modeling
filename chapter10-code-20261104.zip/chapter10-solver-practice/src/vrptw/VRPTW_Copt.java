package vrptw;

import common.VRPTWInstance;
import common.SolverChecks;
import common.read_in;
import common.SolutionIO;
import copt.CoptException;
import copt.Envr;
import copt.Expr;
import copt.Model;
import copt.Var;
import java.util.ArrayList;
import java.util.List;

/** 两下标 VRPTW：最小化距离，车辆数和容量均为上界。 */
public final class VRPTW_Copt {
    private VRPTW_Copt() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--help".equals(args[0])) {
            System.out.println("Usage: vrptw.VRPTW_Copt [instancePath] [timeLimitSec]"
                    + " [vehicleLimit] [customerLimit]");
            return;
        }
        if (args.length > 4) {
            throw new IllegalArgumentException("Too many arguments; use --help.");
        }
        String path = args.length > 0 ? args[0] : "instances/C201.txt";
        double timeLimit = args.length > 1 ? Double.parseDouble(args[1]) : 3600.0;
        int vehicleLimit = args.length > 2 ? Integer.parseInt(args[2]) : 4;
        int customerLimit = args.length > 3 ? Integer.parseInt(args[3]) : 0;
        if (!Double.isFinite(timeLimit) || timeLimit < 0.0) {
            throw new IllegalArgumentException("timeLimitSec must be finite and nonnegative (0 = unlimited).");
        }
        if (vehicleLimit != -1 && vehicleLimit <= 0) {
            throw new IllegalArgumentException("vehicleLimit must be positive or -1 (file default).");
        }
        if (customerLimit < 0) {
            throw new IllegalArgumentException("customerLimit must be nonnegative (0 = all customers).");
        }
        boolean applyMetricClosure = false;
        boolean applyRounding = false;
        boolean applyTruncation = false;
        Envr env = null;
        Model model = null;

        try {
            // 读取实例与基本规模参数
            VRPTWInstance inst = read_in.readSolomon(
                    path, customerLimit, applyMetricClosure, applyRounding, applyTruncation);
            SolverChecks.requirePositiveServiceTimes(inst);
            int n = inst.customerCount;
            int start = inst.start;
            int end = inst.end;
            int nodes = inst.nodeCount;
            int maxVehicles = vehicleLimit > 0 ? vehicleLimit : inst.vehicleCount;
            double capacity = inst.capacity;

            // 创建 COPT 模型
            env = new Envr();
            model = env.createModel("VRPTW_Copt");
            if (timeLimit > 0.0) {
                model.setDblParam(copt.DblParam.TimeLimit, timeLimit);
            }

            // 决策变量 x_ij：是否走弧(i,j)
            Var[][] x = new Var[nodes][nodes];
            for (int i = 0; i < nodes; i++) {
                if (i == end) {
                    continue;
                }
                for (int j = 0; j < nodes; j++) {
                    if (i == j || j == start) {
                        continue;
                    }
                    if (i == start && j == end) {
                        continue;
                    }
                    x[i][j] = model.addVar(0.0, 1.0, inst.distance[i][j],
                            copt.Consts.BINARY, "x_" + i + "_" + j);
                }
            }

            // 决策变量 t_i：客户服务开始时间
            Var[] t = new Var[nodes];
            for (int i = 0; i < nodes; i++) {
                double lb = inst.ready[i];
                double ub = inst.due[i];
                if (i == start) {
                    lb = inst.ready[start];
                    ub = inst.ready[start];
                }
                t[i] = model.addVar(lb, ub, 0.0, copt.Consts.CONTINUOUS, "t_" + i);
            }

            // u_i 为服务完客户后的累计配送量辅助值，可大于实际累计量。
            Var[] u = new Var[nodes];
            for (int i = 1; i <= n; i++) {
                u[i] = model.addVar(inst.demand[i], capacity, 0.0, copt.Consts.CONTINUOUS, "u_" + i);
            }

            // 约束：每个客户恰好一次进出
            for (int i = 1; i <= n; i++) {
                Expr outExpr = new Expr();
                Expr inExpr = new Expr();
                for (int j = 0; j < nodes; j++) {
                    if (x[i][j] != null) {
                        outExpr.addTerm(x[i][j], 1.0);
                    }
                    if (x[j][i] != null) {
                        inExpr.addTerm(x[j][i], 1.0);
                    }
                }
                model.addConstr(outExpr, copt.Consts.EQUAL, 1.0, "out_" + i);
                model.addConstr(inExpr, copt.Consts.EQUAL, 1.0, "in_" + i);
            }

            // 约束：车辆出入仓库数量与上限
            Expr outDepot = new Expr();
            Expr inDepot = new Expr();
            for (int j = 0; j < nodes; j++) {
                if (x[start][j] != null) {
                    outDepot.addTerm(x[start][j], 1.0);
                }
            }
            for (int i = 0; i < nodes; i++) {
                if (x[i][end] != null) {
                    inDepot.addTerm(x[i][end], 1.0);
                }
            }
            model.addConstr(outDepot, copt.Consts.LESS_EQUAL, maxVehicles, "veh_out_limit");
            model.addConstr(inDepot, copt.Consts.LESS_EQUAL, maxVehicles, "veh_in_limit");
            Expr balance = new Expr();
            for (int j = 0; j < nodes; j++) {
                if (x[start][j] != null) {
                    balance.addTerm(x[start][j], 1.0);
                }
            }
            for (int i = 0; i < nodes; i++) {
                if (x[i][end] != null) {
                    balance.addTerm(x[i][end], -1.0);
                }
            }
            model.addConstr(balance, copt.Consts.EQUAL, 0.0, "veh_balance");

            // 约束：时间连续性与时间窗
            for (int i = 0; i < nodes; i++) {
                if (i == end) {
                    continue;
                }
                for (int j = 0; j < nodes; j++) {
                    if (x[i][j] == null) {
                        continue;
                    }
                    double bigM = Math.max(0.0, inst.due[i] + inst.service[i]
                            + inst.travelTime[i][j] - inst.ready[j]);
                    Expr expr = new Expr();
                    expr.addTerm(t[j], 1.0);
                    expr.addTerm(t[i], -1.0);
                    expr.addTerm(x[i][j], -bigM);
                    model.addConstr(expr, copt.Consts.GREATER_EQUAL,
                            inst.service[i] + inst.travelTime[i][j] - bigM,
                            "time_" + i + "_" + j);
                }
            }

            // 约束：载重连续性（从仓库出发）
            for (int j = 1; j <= n; j++) {
                if (x[start][j] != null) {
                    Expr expr = new Expr();
                    expr.addTerm(u[j], 1.0);
                    expr.addTerm(x[start][j], -capacity);
                    model.addConstr(expr, copt.Consts.GREATER_EQUAL, inst.demand[j] - capacity,
                            "load_0_" + j);
                }
            }

            // 约束：载重连续性（客户间转移）
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (i == j || x[i][j] == null) {
                        continue;
                    }
                    Expr expr = new Expr();
                    expr.addTerm(u[j], 1.0);
                    expr.addTerm(u[i], -1.0);
                    expr.addTerm(x[i][j], -capacity);
                    model.addConstr(expr, copt.Consts.GREATER_EQUAL, inst.demand[j] - capacity,
                            "load_" + i + "_" + j);
                }
            }

            // 求解
            model.setObjSense(copt.Consts.MINIMIZE);
            long solveStart = System.nanoTime();
            model.solve();
            double solveSeconds = (System.nanoTime() - solveStart) / 1e9;
            System.out.println("Solve time (s): " + solveSeconds);

            // 输出结果
            int status = model.getIntAttr(copt.IntAttr.MipStatus);
            System.out.println("MIP status: " + status);
            if (model.getIntAttr(copt.IntAttr.HasMipSol) != 0) {
                double objective = model.getDblAttr(copt.DblAttr.BestObj);
                double lowerBound = model.getDblAttr(copt.DblAttr.BestBnd);
                double gap = model.getDblAttr(copt.DblAttr.BestGap);
                System.out.println("Objective: " + objective);
                List<String> routeLines = buildRouteLines(x, start, end);
                String outputPath = SolutionIO.buildSolutionPath(path, "VRPTW_Copt");
                SolutionIO.writeSolution(outputPath, path, inst.name, "VRPTW_Copt",
                        objective, lowerBound, gap, solveSeconds, Integer.toString(status), routeLines);
                System.out.println("Solution saved to: " + outputPath);
            } else {
                System.out.println("No feasible solution available; status: " + status);
                String outputPath = SolutionIO.buildSolutionPath(path, "VRPTW_Copt");
                SolutionIO.writeNoSolution(outputPath, path, inst.name, "VRPTW_Copt",
                        Integer.toString(status), solveSeconds);
                System.out.println("Result saved (status only) to: " + outputPath);
            }
        } finally {
            try {
                if (model != null) {
                    model.dispose();
                }
            } finally {
                if (env != null) {
                    env.dispose();
                }
            }
        }
    }

    private static List<String> buildRouteLines(Var[][] x, int start, int end) throws CoptException {
        int nodes = x.length;
        List<String> lines = new ArrayList<>();
        int routeIndex = 1;
        for (int j = 0; j < nodes; j++) {
            if (x[start][j] != null && x[start][j].get(copt.DblInfo.Value) > 0.5) {
                List<Integer> route = new ArrayList<>();
                route.add(start);
                int current = j;
                route.add(current);
                int guard = 0;
                while (current != end && guard < nodes + 2) {
                    int next = -1;
                    for (int k = 0; k < nodes; k++) {
                        if (x[current][k] != null && x[current][k].get(copt.DblInfo.Value) > 0.5) {
                            next = k;
                            break;
                        }
                    }
                    if (next == -1) {
                        break;
                    }
                    current = next;
                    route.add(current);
                    guard++;
                }
                lines.add(formatRouteLine("route " + routeIndex, route, start, end));
                routeIndex++;
            }
        }
        return lines;
    }

    private static String formatRouteLine(String label, List<Integer> route, int start, int end) {
        if (route.size() < 2 || route.get(route.size() - 1) != end) {
            throw new IllegalStateException("Selected arcs do not form a closed route: " + route);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(label).append(":");
        for (int node : route) {
            int outputNode = node == end ? start : node;
            sb.append(' ').append(outputNode);
        }
        return sb.toString();
    }
}
