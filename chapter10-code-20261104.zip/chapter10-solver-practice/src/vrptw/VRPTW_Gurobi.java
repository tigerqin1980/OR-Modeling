package vrptw;

import common.VRPTWInstance;
import common.SolverChecks;
import common.read_in;
import common.SolutionIO;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;
import java.util.ArrayList;
import java.util.List;

/** 两下标 VRPTW：最小化距离，车辆数和容量均为上界。 */
public final class VRPTW_Gurobi {
    private VRPTW_Gurobi() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--help".equals(args[0])) {
            System.out.println("Usage: vrptw.VRPTW_Gurobi [instancePath] [timeLimitSec]"
                    + " [vehicleLimit] [customerLimit]");
            return;
        }
        if (args.length > 4) {
            throw new IllegalArgumentException("Too many arguments; use --help.");
        }
        String path = args.length > 0 ? args[0] : "instances/C201.txt";
        double timeLimit = args.length > 1 ? Double.parseDouble(args[1]) : 3600.0;
        int vehicleLimit = args.length > 2 ? Integer.parseInt(args[2]) : 4;
        int customerLimit = args.length > 3 ? Integer.parseInt(args[3]) : 0;
        if (!Double.isFinite(timeLimit) || timeLimit < 0.0) {
            throw new IllegalArgumentException("timeLimitSec must be finite and nonnegative (0 = unlimited).");
        }
        if (vehicleLimit != -1 && vehicleLimit <= 0) {
            throw new IllegalArgumentException("vehicleLimit must be positive or -1 (file default).");
        }
        if (customerLimit < 0) {
            throw new IllegalArgumentException("customerLimit must be nonnegative (0 = all customers).");
        }
        boolean applyMetricClosure = false;
        boolean applyRounding = false;
        boolean applyTruncation = false;
        GRBEnv env = null;
        GRBModel model = null;

        try {
            VRPTWInstance inst = read_in.readSolomon(
                    path,
                    customerLimit,
                    applyMetricClosure,
                    applyRounding,
                    applyTruncation);
            SolverChecks.requirePositiveServiceTimes(inst);
            int n = inst.customerCount;
            int start = inst.start;
            int end = inst.end;
            int nodes = inst.nodeCount;
            int maxVehicles = vehicleLimit > 0 ? vehicleLimit : inst.vehicleCount;
            double capacity = inst.capacity;

            env = new GRBEnv();
            model = new GRBModel(env);
            model.set(GRB.StringAttr.ModelName, "VRPTW_Gurobi");
            if (timeLimit > 0.0) {
                model.set(GRB.DoubleParam.TimeLimit, timeLimit);
            }

            GRBVar[][] x = new GRBVar[nodes][nodes];
            GRBLinExpr obj = new GRBLinExpr();
            for (int i = 0; i < nodes; i++) {
                if (i == end) {
                    continue;
                }
                for (int j = 0; j < nodes; j++) {
                    if (i == j || j == start) {
                        continue;
                    }
                    if (i == start && j == end) {
                        continue;
                    }
                    x[i][j] = model.addVar(0.0, 1.0, 0.0, GRB.BINARY,
                            "x_" + i + "_" + j);
                    obj.addTerm(inst.distance[i][j], x[i][j]);
                }
            }

            GRBVar[] t = new GRBVar[nodes];
            for (int i = 0; i < nodes; i++) {
                double lb = inst.ready[i];
                double ub = inst.due[i];
                if (i == start) {
                    lb = inst.ready[start];
                    ub = inst.ready[start];
                }
                t[i] = model.addVar(lb, ub, 0.0, GRB.CONTINUOUS, "t_" + i);
            }

            GRBVar[] u = new GRBVar[nodes];
            for (int i = 1; i <= n; i++) {
                u[i] = model.addVar(inst.demand[i], capacity, 0.0, GRB.CONTINUOUS, "u_" + i);
            }

            model.update();

            for (int i = 1; i <= n; i++) {
                GRBLinExpr outExpr = new GRBLinExpr();
                GRBLinExpr inExpr = new GRBLinExpr();
                for (int j = 0; j < nodes; j++) {
                    if (x[i][j] != null) {
                        outExpr.addTerm(1.0, x[i][j]);
                    }
                    if (x[j][i] != null) {
                        inExpr.addTerm(1.0, x[j][i]);
                    }
                }
                model.addConstr(outExpr, GRB.EQUAL, 1.0, "out_" + i);
                model.addConstr(inExpr, GRB.EQUAL, 1.0, "in_" + i);
            }

            GRBLinExpr outDepot = new GRBLinExpr();
            GRBLinExpr inDepot = new GRBLinExpr();
            for (int j = 0; j < nodes; j++) {
                if (x[start][j] != null) {
                    outDepot.addTerm(1.0, x[start][j]);
                }
            }
            for (int i = 0; i < nodes; i++) {
                if (x[i][end] != null) {
                    inDepot.addTerm(1.0, x[i][end]);
                }
            }
            model.addConstr(outDepot, GRB.LESS_EQUAL, maxVehicles, "veh_out_limit");
            model.addConstr(inDepot, GRB.LESS_EQUAL, maxVehicles, "veh_in_limit");
            GRBLinExpr balance = new GRBLinExpr();
            for (int j = 0; j < nodes; j++) {
                if (x[start][j] != null) {
                    balance.addTerm(1.0, x[start][j]);
                }
            }
            for (int i = 0; i < nodes; i++) {
                if (x[i][end] != null) {
                    balance.addTerm(-1.0, x[i][end]);
                }
            }
            model.addConstr(balance, GRB.EQUAL, 0.0, "veh_balance");

            for (int i = 0; i < nodes; i++) {
                if (i == end) {
                    continue;
                }
                for (int j = 0; j < nodes; j++) {
                    if (x[i][j] == null) {
                        continue;
                    }
                    double bigM = Math.max(0.0, inst.due[i] + inst.service[i]
                            + inst.travelTime[i][j] - inst.ready[j]);
                    GRBLinExpr expr = new GRBLinExpr();
                    expr.addTerm(1.0, t[j]);
                    expr.addTerm(-1.0, t[i]);
                    expr.addTerm(-bigM, x[i][j]);
                    model.addConstr(expr, GRB.GREATER_EQUAL,
                            inst.service[i] + inst.travelTime[i][j] - bigM,
                            "time_" + i + "_" + j);
                }
            }

            for (int j = 1; j <= n; j++) {
                if (x[start][j] != null) {
                    GRBLinExpr expr = new GRBLinExpr();
                    expr.addTerm(1.0, u[j]);
                    expr.addTerm(-capacity, x[start][j]);
                    model.addConstr(expr, GRB.GREATER_EQUAL,
                            inst.demand[j] - capacity,
                            "load_0_" + j);
                }
            }

            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (i == j || x[i][j] == null) {
                        continue;
                    }
                    GRBLinExpr expr = new GRBLinExpr();
                    expr.addTerm(1.0, u[j]);
                    expr.addTerm(-1.0, u[i]);
                    expr.addTerm(-capacity, x[i][j]);
                    model.addConstr(expr, GRB.GREATER_EQUAL,
                            inst.demand[j] - capacity,
                            "load_" + i + "_" + j);
                }
            }

            model.setObjective(obj, GRB.MINIMIZE);
            long solveStart = System.nanoTime();
            model.optimize();
            double solveSeconds = (System.nanoTime() - solveStart) / 1e9;
            System.out.println("Solve time (s): " + solveSeconds);

            int status = model.get(GRB.IntAttr.Status);
            System.out.println("MIP status: " + status);
            if (model.get(GRB.IntAttr.SolCount) > 0) {
                double objective = model.get(GRB.DoubleAttr.ObjVal);
                double lowerBound = model.get(GRB.DoubleAttr.ObjBound);
                double gap = model.get(GRB.DoubleAttr.MIPGap);
                System.out.println("Objective: " + objective);
                List<String> routeLines = buildRouteLines(x, start, end);
                String outputPath = SolutionIO.buildSolutionPath(path, "VRPTW_Gurobi");
                SolutionIO.writeSolution(outputPath, path, inst.name, "VRPTW_Gurobi",
                        objective, lowerBound, gap, solveSeconds, Integer.toString(status), routeLines);
                System.out.println("Solution saved to: " + outputPath);
            } else {
                System.out.println("No feasible solution available; status: " + status);
                String outputPath = SolutionIO.buildSolutionPath(path, "VRPTW_Gurobi");
                SolutionIO.writeNoSolution(outputPath, path, inst.name, "VRPTW_Gurobi",
                        Integer.toString(status), solveSeconds);
                System.out.println("Result saved (status only) to: " + outputPath);
            }

        } finally {
            try {
                if (model != null) {
                    model.dispose();
                }
            } finally {
                if (env != null) {
                    env.dispose();
                }
            }
        }
    }

    private static List<String> buildRouteLines(GRBVar[][] x, int start, int end) throws GRBException {
        int nodes = x.length;
        List<String> lines = new ArrayList<>();
        int routeIndex = 1;
        for (int j = 0; j < nodes; j++) {
            if (x[start][j] != null && x[start][j].get(GRB.DoubleAttr.X) > 0.5) {
                List<Integer> route = new ArrayList<>();
                route.add(start);
                int current = j;
                route.add(current);
                int guard = 0;
                while (current != end && guard < nodes + 2) {
                    int next = -1;
                    for (int k = 0; k < nodes; k++) {
                        if (x[current][k] != null && x[current][k].get(GRB.DoubleAttr.X) > 0.5) {
                            next = k;
                            break;
                        }
                    }
                    if (next == -1) {
                        break;
                    }
                    current = next;
                    route.add(current);
                    guard++;
                }
                lines.add(formatRouteLine("route " + routeIndex, route, start, end));
                routeIndex++;
            }
        }
        return lines;
    }

    private static String formatRouteLine(String label, List<Integer> route, int start, int end) {
        if (route.size() < 2 || route.get(route.size() - 1) != end) {
            throw new IllegalStateException("Selected arcs do not form a closed route: " + route);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(label).append(":");
        for (int node : route) {
            int outputNode = node == end ? start : node;
            sb.append(' ').append(outputNode);
        }
        return sb.toString();
    }
}
