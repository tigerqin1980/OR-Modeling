package mtvrptwmsm;

import common.MSMInstance;
import common.VRPTWInstance;
import common.SolverChecks;
import common.read_in_MTVRPTW_msm;
import common.SolutionIO;
import copt.CoptException;
import copt.Envr;
import copt.Expr;
import copt.Model;
import copt.Var;
import java.util.ArrayList;
import java.util.List;

/**
 * Huang等(2024)补充材料Appendix A的弧流模型，公式(A.1)—(A.33)。
 * 人员数按高技能到低技能累计；给定的每辆车都必须执行行程并安排午休。
 * (A.7)作等价线性化，大M按有限时间窗计算；详见docs/book-code-alignment.md。
 */
public final class MTVRPTW_MSM_Copt {
    private MTVRPTW_MSM_Copt() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--help".equals(args[0])) {
            System.out.println("Usage: mtvrptwmsm.MTVRPTW_MSM_Copt [instancePath] [timeLimitSec]"
                    + " [vehicleCount] [customerLimit] [tripLimit]");
            return;
        }
        if (args.length > 5) {
            throw new IllegalArgumentException("Too many arguments; use --help.");
        }
        String path = args.length > 0 ? args[0] : "instances/Solomon_2/C201.txt";
        double timeLimit = args.length > 1 ? Double.parseDouble(args[1]) : 3600.0;
        int vehicleCount = args.length > 2 ? Integer.parseInt(args[2]) : 2;
        int customerLimit = args.length > 3 ? Integer.parseInt(args[3]) : 16;
        if (!Double.isFinite(timeLimit) || timeLimit < 0.0) {
            throw new IllegalArgumentException("timeLimitSec must be finite and nonnegative (0 = unlimited).");
        }
        if (vehicleCount <= 0) {
            throw new IllegalArgumentException("vehicleCount must be positive; MSM files do not define fleet size.");
        }
        if (customerLimit < 0) {
            throw new IllegalArgumentException("customerLimit must be nonnegative (0 = all customers).");
        }
        boolean applyMetricClosure = true;
        boolean applyRounding = true;
        boolean applyTruncation = true;
        int tripLimit = args.length > 4 ? Integer.parseInt(args[4]) : 6;
        if (tripLimit <= 0) {
            throw new IllegalArgumentException("tripLimit must be positive.");
        }
        double capacityLimit = 12.0;
        Envr env = null;
        Model model = null;

        try {
            MSMInstance msm = read_in_MTVRPTW_msm.readSolomonMSM(
                    path,
                    customerLimit,
                    applyMetricClosure,
                    applyRounding,
                    applyTruncation);
            VRPTWInstance inst = msm.base;
            SolverChecks.requirePositiveServiceTimes(inst);
            int n = inst.customerCount;
            int nodes = n + 1; // depot 0 + customers 1..n
            int start = inst.start;
            int vehicles = vehicleCount;
            int maxTrips = tripLimit; // 默认6为论文小规模实验设置；取客户数可放宽行程上限。
            double capacity = capacityLimit;

            double horizon = inst.due[start];
            double lunchStart = horizon * 0.4;
            double lunchEnd = horizon * 0.6;
            double lunchDuration = horizon / 10.0;
            double depotReady = inst.ready[start];
            double sequenceM = horizon - depotReady + lunchDuration;
            double lunchLowerM = Math.max(0.0, lunchStart - depotReady);
            double lunchUpperM = Math.max(0.0, horizon - lunchEnd);
            double lunchDepartM = Math.max(0.0, horizon - lunchStart);

            int skillLevels = msm.staffTypes;
            if (skillLevels != 2) {
                throw new IllegalArgumentException("Expected 2 staff types for MSM Solomon_2 instances.");
            }
            int[] staffCount = new int[skillLevels + 1];
            double[] staffCost = new double[skillLevels + 1];
            staffCount[1] = 1;
            staffCount[2] = 3;
            staffCost[1] = 45.0;
            staffCost[2] = 40.0;

            // nStaff 是累计人数，上界也必须累计：本例为1、4，不能使用单级人数1、3。
            int[] staffCountCum = new int[skillLevels + 1];
            for (int level = 1; level <= skillLevels; level++) {
                staffCountCum[level] = staffCountCum[level - 1] + staffCount[level];
            }

            // 文件按低技能到高技能给出分级需求；模型下标按高技能到低技能累计。
            int[][] staffReq = new int[skillLevels + 1][nodes];
            int[][] staffReqCum = new int[skillLevels + 1][nodes];
            for (int i = 1; i <= n; i++) {
                for (int level = 1; level <= skillLevels; level++) {
                    int rawIndex = skillLevels - level;
                    staffReq[level][i] = msm.staffRaw[rawIndex][i];
                }
            }
            for (int i = 1; i <= n; i++) {
                int cum = 0;
                for (int a = 1; a <= skillLevels; a++) {
                    cum += staffReq[a][i];
                    staffReqCum[a][i] = cum;
                }
            }

            env = new Envr();
            model = env.createModel("MTVRPTW_MSM_Copt");
            if (timeLimit > 0.0) {
                model.setDblParam(copt.DblParam.TimeLimit, timeLimit);
            }

            Var[][] x = new Var[nodes][nodes];
            Var[][] xStart = new Var[maxTrips][nodes];
            Var[][] z = new Var[maxTrips][nodes];
            Var[] a = new Var[nodes];
            Var[] dep = new Var[maxTrips];
            Var[] ret = new Var[maxTrips];
            Var[][] v = new Var[vehicles][maxTrips];
            Var[][][] w = new Var[vehicles][maxTrips][maxTrips];
            Var[][] lunch = new Var[vehicles][maxTrips];
            Var[][] nStaff = new Var[skillLevels + 1][maxTrips];
            Var[][][] staffAssign = new Var[skillLevels + 1][][];
            Var[][][][] staffOrder = new Var[skillLevels + 1][][][];

            // A.27—A.32及变量定义：二进制弧、分配、排序和午休变量；ζ为非负整数。
            for (int i = 0; i < nodes; i++) {
                for (int j = 0; j < nodes; j++) {
                    if (i == j) {
                        continue;
                    }
                    x[i][j] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                            "x_" + i + "_" + j);
                }
            }

            // A.3：i=0表示空行程；其余i为首个客户。
            for (int k = 0; k < maxTrips; k++) {
                xStart[k][0] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                        "x0_" + (k + 1) + "_0");
                for (int i = 1; i <= n; i++) {
                    xStart[k][i] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                            "x0_" + (k + 1) + "_" + i);
                    z[k][i] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                            "z_" + (k + 1) + "_" + i);
                }
            }

            // A.23, A.33：客户时间窗 e_i <= a_i <= l_i（通过变量上下界实现）
            for (int i = 1; i <= n; i++) {
                a[i] = model.addVar(inst.ready[i], inst.due[i], 0.0, copt.Consts.CONTINUOUS,
                        "a_" + i);
            }

            for (int k = 0; k < maxTrips; k++) {
                dep[k] = model.addVar(inst.ready[start], inst.due[start], 0.0, copt.Consts.CONTINUOUS,
                        "dep_" + (k + 1));
                ret[k] = model.addVar(inst.ready[start], inst.due[start], 0.0, copt.Consts.CONTINUOUS,
                        "ret_" + (k + 1));
            }

            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    v[h][k] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                            "v_" + (h + 1) + "_" + (k + 1));
                    lunch[h][k] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                            "lunch_" + (h + 1) + "_" + (k + 1));
                }
            }

            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int l = 0; l < maxTrips; l++) {
                        if (k == l) {
                            continue;
                        }
                        w[h][k][l] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                                "w_" + (h + 1) + "_" + (k + 1) + "_" + (l + 1));
                    }
                }
            }

            for (int aLevel = 1; aLevel <= skillLevels; aLevel++) {
                staffAssign[aLevel] = new Var[staffCount[aLevel]][maxTrips];
                staffOrder[aLevel] = new Var[staffCount[aLevel]][maxTrips][maxTrips];
                for (int d = 0; d < staffCount[aLevel]; d++) {
                    for (int k = 0; k < maxTrips; k++) {
                        staffAssign[aLevel][d][k] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                                "y_" + aLevel + "_" + (d + 1) + "_" + (k + 1));
                    }
                    for (int k = 0; k < maxTrips; k++) {
                        for (int l = 0; l < maxTrips; l++) {
                            if (k == l) {
                                continue;
                            }
                            staffOrder[aLevel][d][k][l] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                                    "r_" + aLevel + "_" + (d + 1) + "_" + (k + 1) + "_" + (l + 1));
                        }
                    }
                }
            }

            for (int aLevel = 1; aLevel <= skillLevels; aLevel++) {
                for (int k = 0; k < maxTrips; k++) {
                    nStaff[aLevel][k] = model.addVar(0.0, staffCountCum[aLevel], 0.0, copt.Consts.INTEGER,
                            "n_" + aLevel + "_" + (k + 1));
                }
            }

            Expr obj = new Expr();
            for (int i = 0; i < nodes; i++) {
                for (int j = 0; j < nodes; j++) {
                    if (i == j) {
                        continue;
                    }
                    if (x[i][j] != null) {
                        obj.addTerm(x[i][j], inst.distance[i][j]);
                    }
                }
            }
            for (int k = 0; k < maxTrips; k++) {
                obj.addTerm(nStaff[1][k], staffCost[1]);
                for (int aLevel = 2; aLevel <= skillLevels; aLevel++) {
                    obj.addTerm(nStaff[aLevel][k], staffCost[aLevel]);
                    obj.addTerm(nStaff[aLevel - 1][k], -staffCost[aLevel]);
                }
            }
            // A.1：最小化总成本（行驶成本 + 人员成本）
            model.setObjective(obj, copt.Consts.MINIMIZE);

            // A.2：客户节点流守恒
            for (int j = 1; j <= n; j++) {
                Expr inExpr = new Expr();
                Expr outExpr = new Expr();
                for (int i = 0; i < nodes; i++) {
                    if (i == j) {
                        continue;
                    }
                    if (x[i][j] != null) {
                        inExpr.addTerm(x[i][j], 1.0);
                    }
                    if (x[j][i] != null) {
                        outExpr.addTerm(x[j][i], 1.0);
                    }
                }
                model.addConstr(inExpr, copt.Consts.EQUAL, 1.0, "flow_in_" + j);
                model.addConstr(outExpr, copt.Consts.EQUAL, 1.0, "flow_out_" + j);
            }

            // A.3：每个行程选择一个起点弧（含表示空行程的 xStart[k][0]）
            for (int k = 0; k < maxTrips; k++) {
                Expr expr = new Expr();
                for (int i = 0; i <= n; i++) {
                    expr.addTerm(xStart[k][i], 1.0);
                }
                model.addConstr(expr, copt.Consts.EQUAL, 1.0, "trip_start_" + (k + 1));
            }

            // A.4：仓库出发弧与行程起点关联
            for (int i = 1; i <= n; i++) {
                Expr expr = new Expr();
                for (int k = 0; k < maxTrips; k++) {
                    expr.addTerm(xStart[k][i], 1.0);
                }
                if (x[start][i] != null) {
                    expr.addTerm(x[start][i], -1.0);
                }
                model.addConstr(expr, copt.Consts.EQUAL, 0.0, "start_link_" + i);
            }

            // A.5：每个客户仅被一个行程服务
            for (int i = 1; i <= n; i++) {
                Expr expr = new Expr();
                for (int k = 0; k < maxTrips; k++) {
                    expr.addTerm(z[k][i], 1.0);
                }
                model.addConstr(expr, copt.Consts.EQUAL, 1.0, "visit_" + i);
            }

            // A.6：行程起点客户必须属于该行程
            for (int k = 0; k < maxTrips; k++) {
                for (int i = 1; i <= n; i++) {
                    Expr expr = new Expr();
                    expr.addTerm(xStart[k][i], 1.0);
                    expr.addTerm(z[k][i], -1.0);
                    model.addConstr(expr, copt.Consts.LESS_EQUAL, 0.0,
                            "start_member_" + (k + 1) + "_" + i);
                }
            }

            // A.7：二进制变量乘积条件等价为两条线性不等式。
            for (int k = 0; k < maxTrips; k++) {
                for (int i = 1; i <= n; i++) {
                    for (int j = 1; j <= n; j++) {
                        if (i == j) {
                            continue;
                        }
                        Expr expr1 = new Expr();
                        expr1.addTerm(z[k][i], 1.0);
                        expr1.addTerm(z[k][j], -1.0);
                        expr1.addTerm(x[i][j], 1.0);
                        model.addConstr(expr1, copt.Consts.LESS_EQUAL, 1.0,
                                "trip_cons_1_" + (k + 1) + "_" + i + "_" + j);

                        Expr expr2 = new Expr();
                        expr2.addTerm(z[k][j], 1.0);
                        expr2.addTerm(z[k][i], -1.0);
                        expr2.addTerm(x[i][j], 1.0);
                        model.addConstr(expr2, copt.Consts.LESS_EQUAL, 1.0,
                                "trip_cons_2_" + (k + 1) + "_" + i + "_" + j);
                    }
                }
            }

            // A.8：客户间服务时间连续性
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (i == j) {
                        continue;
                    }
                    double bigM = Math.max(0.0, inst.due[i] + inst.service[i]
                            + inst.travelTime[i][j] - inst.ready[j]);
                    Expr expr = new Expr();
                    expr.addTerm(a[i], 1.0);
                    expr.addTerm(a[j], -1.0);
                    expr.addTerm(x[i][j], bigM);
                    model.addConstr(expr, copt.Consts.LESS_EQUAL,
                            bigM - inst.service[i] - inst.travelTime[i][j],
                            "time_link_" + i + "_" + j);
                }
            }

            // A.9：行程返回时间与最后客户完成时间
            for (int k = 0; k < maxTrips; k++) {
                for (int i = 1; i <= n; i++) {
                    double bigM = Math.max(0.0, inst.due[i] + inst.service[i]
                            + inst.travelTime[i][start] - depotReady);
                    Expr expr = new Expr();
                    expr.addTerm(a[i], 1.0);
                    expr.addTerm(ret[k], -1.0);
                    expr.addTerm(x[i][start], bigM);
                    expr.addTerm(z[k][i], bigM);
                    model.addConstr(expr, copt.Consts.LESS_EQUAL,
                            2.0 * bigM - inst.service[i] - inst.travelTime[i][start],
                            "return_time_" + (k + 1) + "_" + i);
                }
            }

            // A.10：行程出发时间与首个客户服务时间
            for (int k = 0; k < maxTrips; k++) {
                for (int i = 1; i <= n; i++) {
                    double bigM = Math.max(0.0, horizon
                            + inst.travelTime[start][i] - inst.ready[i]);
                    Expr expr = new Expr();
                    expr.addTerm(dep[k], 1.0);
                    expr.addTerm(a[i], -1.0);
                    expr.addTerm(xStart[k][i], bigM);
                    model.addConstr(expr, copt.Consts.LESS_EQUAL,
                            bigM - inst.travelTime[start][i],
                            "depart_time_" + (k + 1) + "_" + i);
                }
            }

            // A.11：每辆给定车辆恰好选择一个返场午休行程，右端为1。
            for (int h = 0; h < vehicles; h++) {
                Expr lunchCount = new Expr();
                for (int k = 0; k < maxTrips; k++) {
                    lunchCount.addTerm(lunch[h][k], 1.0);
                }
                model.addConstr(lunchCount, copt.Consts.EQUAL, 1.0, "lunch_once_" + (h + 1));
            }

            // A.12：仅在执行该行程后安排午休
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    Expr expr = new Expr();
                    expr.addTerm(lunch[h][k], 1.0);
                    expr.addTerm(v[h][k], -1.0);
                    model.addConstr(expr, copt.Consts.LESS_EQUAL, 0.0,
                            "lunch_link_" + (h + 1) + "_" + (k + 1));
                }
            }

            // A.13：行程与车辆分配一致
            for (int k = 0; k < maxTrips; k++) {
                Expr expr = new Expr();
                for (int i = 1; i <= n; i++) {
                    expr.addTerm(xStart[k][i], 1.0);
                }
                for (int h = 0; h < vehicles; h++) {
                    expr.addTerm(v[h][k], -1.0);
                }
                model.addConstr(expr, copt.Consts.EQUAL, 0.0, "assign_" + (k + 1));
            }

            // A.14, A.15：车辆行程顺序唯一性
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int l = k + 1; l < maxTrips; l++) {
                        Expr expr = new Expr();
                        expr.addTerm(v[h][k], 1.0);
                        expr.addTerm(v[h][l], 1.0);
                        expr.addTerm(w[h][k][l], -1.0);
                        expr.addTerm(w[h][l][k], -1.0);
                        model.addConstr(expr, copt.Consts.LESS_EQUAL, 1.0,
                                "veh_order_1_" + (h + 1) + "_" + (k + 1) + "_" + (l + 1));

                        Expr expr2 = new Expr();
                        expr2.addTerm(w[h][k][l], 1.0);
                        expr2.addTerm(w[h][l][k], 1.0);
                        model.addConstr(expr2, copt.Consts.LESS_EQUAL, 1.0,
                                "veh_order_2_" + (h + 1) + "_" + (k + 1) + "_" + (l + 1));
                    }
                }
            }

            // A.16：车辆行程时序与午休衔接
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int l = 0; l < maxTrips; l++) {
                        if (k == l) {
                            continue;
                        }
                        Expr expr = new Expr();
                        expr.addTerm(ret[k], 1.0);
                        expr.addTerm(dep[l], -1.0);
                        expr.addTerm(lunch[h][k], lunchDuration);
                        expr.addTerm(w[h][k][l], sequenceM);
                        model.addConstr(expr, copt.Consts.LESS_EQUAL, sequenceM,
                                "veh_time_" + (h + 1) + "_" + (k + 1) + "_" + (l + 1));
                    }
                }
            }

            // A.17, A.18：人员行程顺序唯一性
            for (int aLevel = 1; aLevel <= skillLevels; aLevel++) {
                for (int d = 0; d < staffCount[aLevel]; d++) {
                    for (int k = 0; k < maxTrips; k++) {
                        for (int l = k + 1; l < maxTrips; l++) {
                            Expr expr = new Expr();
                            expr.addTerm(staffAssign[aLevel][d][k], 1.0);
                            expr.addTerm(staffAssign[aLevel][d][l], 1.0);
                            expr.addTerm(staffOrder[aLevel][d][k][l], -1.0);
                            expr.addTerm(staffOrder[aLevel][d][l][k], -1.0);
                            model.addConstr(expr, copt.Consts.LESS_EQUAL, 1.0,
                                    "staff_order_1_" + aLevel + "_" + (d + 1) + "_" + (k + 1) + "_" + (l + 1));

                            Expr expr2 = new Expr();
                            expr2.addTerm(staffOrder[aLevel][d][k][l], 1.0);
                            expr2.addTerm(staffOrder[aLevel][d][l][k], 1.0);
                            model.addConstr(expr2, copt.Consts.LESS_EQUAL, 1.0,
                                    "staff_order_2_" + aLevel + "_" + (d + 1) + "_" + (k + 1) + "_" + (l + 1));
                        }
                    }
                }
            }

            // A.19：人员行程时序与午休衔接
            for (int aLevel = 1; aLevel <= skillLevels; aLevel++) {
                for (int d = 0; d < staffCount[aLevel]; d++) {
                    for (int k = 0; k < maxTrips; k++) {
                        Expr lunchSum = new Expr();
                        for (int h = 0; h < vehicles; h++) {
                            lunchSum.addTerm(lunch[h][k], 1.0);
                        }
                        for (int l = 0; l < maxTrips; l++) {
                            if (k == l) {
                                continue;
                            }
                            Expr expr = new Expr();
                            expr.addTerm(ret[k], 1.0);
                            expr.addTerm(dep[l], -1.0);
                            expr.addExpr(lunchSum, lunchDuration);
                            expr.addTerm(staffOrder[aLevel][d][k][l], sequenceM);
                            model.addConstr(expr, copt.Consts.LESS_EQUAL, sequenceM,
                                    "staff_time_" + aLevel + "_" + (d + 1) + "_" + (k + 1) + "_" + (l + 1));
                        }
                    }
                }
            }

            // A.20：行程人员需求覆盖（技能降级）
            for (int k = 0; k < maxTrips; k++) {
                for (int i = 1; i <= n; i++) {
                    for (int aLevel = 1; aLevel <= skillLevels; aLevel++) {
                        int req = staffReqCum[aLevel][i];
                        if (req <= 0) {
                            continue;
                        }
                        Expr expr = new Expr();
                        expr.addTerm(nStaff[aLevel][k], 1.0);
                        expr.addTerm(z[k][i], -req);
                        model.addConstr(expr, copt.Consts.GREATER_EQUAL, 0.0,
                                "skill_req_" + (k + 1) + "_" + i + "_" + aLevel);
                    }
                }
            }

            // A.21：行程人员数与分配一致
            for (int k = 0; k < maxTrips; k++) {
                for (int aLevel = 1; aLevel <= skillLevels; aLevel++) {
                    Expr expr = new Expr();
                    for (int b = 1; b <= aLevel; b++) {
                        for (int d = 0; d < staffCount[b]; d++) {
                            expr.addTerm(staffAssign[b][d][k], 1.0);
                        }
                    }
                    expr.addTerm(nStaff[aLevel][k], -1.0);
                    model.addConstr(expr, copt.Consts.EQUAL, 0.0,
                            "staff_count_" + (k + 1) + "_" + aLevel);
                }
            }

            // A.22：车辆容量限制
            for (int k = 0; k < maxTrips; k++) {
                Expr expr = new Expr();
                for (int i = 1; i <= n; i++) {
                    expr.addTerm(z[k][i], inst.demand[i]);
                }
                expr.addTerm(nStaff[skillLevels][k], 1.0);
                model.addConstr(expr, copt.Consts.LESS_EQUAL, capacity,
                        "capacity_" + (k + 1));
            }

            // A.24：行程出发与返回时间窗
            for (int k = 0; k < maxTrips; k++) {
                Expr expr = new Expr();
                expr.addTerm(dep[k], 1.0);
                expr.addTerm(ret[k], -1.0);
                model.addConstr(expr, copt.Consts.LESS_EQUAL, 0.0,
                        "trip_time_" + (k + 1));
            }

            // A.25：午休开始时间窗
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    Expr lb = new Expr();
                    lb.addTerm(ret[k], 1.0);
                    lb.addTerm(lunch[h][k], -lunchLowerM);
                    model.addConstr(lb, copt.Consts.GREATER_EQUAL, lunchStart - lunchLowerM,
                            "lunch_lb_" + (h + 1) + "_" + (k + 1));

                    Expr ub = new Expr();
                    ub.addTerm(ret[k], 1.0);
                    ub.addTerm(lunch[h][k], lunchUpperM);
                    model.addConstr(ub, copt.Consts.LESS_EQUAL, lunchEnd + lunchUpperM,
                            "lunch_ub_" + (h + 1) + "_" + (k + 1));
                }
            }

            // A.26：午休前出发时间限制
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    Expr expr = new Expr();
                    expr.addTerm(dep[k], 1.0);
                    expr.addTerm(lunch[h][k], lunchDepartM);
                    model.addConstr(expr, copt.Consts.LESS_EQUAL, lunchStart + lunchDepartM,
                            "lunch_depart_" + (h + 1) + "_" + (k + 1));
                }
            }

            long solveStart = System.nanoTime();
            model.solve();
            double solveSeconds = (System.nanoTime() - solveStart) / 1e9;
            System.out.println("Solve time (s): " + solveSeconds);
            int status = model.getIntAttr(copt.IntAttr.MipStatus);
            System.out.println("MIP status: " + status);
            if (model.getIntAttr(copt.IntAttr.HasMipSol) != 0) {
                double objective = model.getDblAttr(copt.DblAttr.BestObj);
                double lowerBound = model.getDblAttr(copt.DblAttr.BestBnd);
                double gap = model.getDblAttr(copt.DblAttr.BestGap);
                System.out.println("Objective: " + objective);
                List<String> routeLines = buildRouteLines(x, xStart, v, start, nodes, maxTrips, vehicles, dep, ret, nStaff, lunch, staffAssign);
                String outputPath = SolutionIO.buildSolutionPath(path, "MTVRPTW_MSM_Copt");
                SolutionIO.writeSolution(outputPath, path, inst.name, "MTVRPTW_MSM_Copt",
                        objective, lowerBound, gap, solveSeconds, Integer.toString(status), routeLines);
                System.out.println("Solution saved to: " + outputPath);
            } else {
                System.out.println("No feasible solution available; status: " + status);
                String outputPath = SolutionIO.buildSolutionPath(path, "MTVRPTW_MSM_Copt");
                SolutionIO.writeNoSolution(outputPath, path, inst.name, "MTVRPTW_MSM_Copt",
                        Integer.toString(status), solveSeconds);
                System.out.println("Result saved (status only) to: " + outputPath);
            }
        } finally {
            try {
                if (model != null) {
                    model.dispose();
                }
            } finally {
                if (env != null) {
                    env.dispose();
                }
            }
        }
    }

    private static List<String> buildRouteLines(
            Var[][] x,
            Var[][] xStart,
            Var[][] v,
            int start,
            int nodes,
            int maxTrips,
            int vehicles,
            Var[] dep,
            Var[] ret,
            Var[][] nStaff,
            Var[][] lunch,
            Var[][][] staffAssign) throws CoptException {
        List<String> lines = new ArrayList<>();
        for (int k = 0; k < maxTrips; k++) {
            int first = -1;
            for (int i = 1; i < nodes; i++) {
                if (xStart[k][i] != null && xStart[k][i].get(copt.DblInfo.Value) > 0.5) {
                    first = i;
                    break;
                }
            }
            if (first == -1) {
                continue;
            }
            int vehicle = -1;
            for (int h = 0; h < vehicles; h++) {
                if (v[h][k] != null && v[h][k].get(copt.DblInfo.Value) > 0.5) {
                    vehicle = h + 1;
                    break;
                }
            }
            List<Integer> route = new ArrayList<>();
            route.add(start);
            int current = first;
            int guard = 0;
            while (guard < nodes + 2) {
                route.add(current);
                if (current == start) {
                    break;
                }
                int next = -1;
                for (int j = 0; j < nodes; j++) {
                    if (j == current || x[current][j] == null) {
                        continue;
                    }
                    if (x[current][j].get(copt.DblInfo.Value) > 0.5) {
                        next = j;
                        break;
                    }
                }
                if (next == -1) {
                    break;
                }
                current = next;
                guard++;
            }
            String label = vehicle > 0
                    ? "trip k=" + (k + 1) + " v=" + vehicle
                    : "trip k=" + (k + 1);
            lines.add(formatRouteLine(label, route));
            StringBuilder schedule = new StringBuilder("schedule k=" + (k + 1));
            schedule.append(" departure=").append(dep[k].get(copt.DblInfo.Value));
            schedule.append(" return=").append(ret[k].get(copt.DblInfo.Value));
            schedule.append(" staffCum=");
            for (int level = 1; level < nStaff.length; level++) {
                if (level > 1) {
                    schedule.append(',');
                }
                schedule.append(Math.round(nStaff[level][k].get(copt.DblInfo.Value)));
            }
            for (int h = 0; h < vehicles; h++) {
                if (lunch[h][k].get(copt.DblInfo.Value) > 0.5) {
                    schedule.append(" lunchVehicle=").append(h + 1);
                }
            }
            schedule.append(" staffIds=");
            boolean firstStaff = true;
            for (int level = 1; level < staffAssign.length; level++) {
                for (int person = 0; person < staffAssign[level].length; person++) {
                    if (staffAssign[level][person][k].get(copt.DblInfo.Value) > 0.5) {
                        if (!firstStaff) {
                            schedule.append(',');
                        }
                        schedule.append(level).append('.').append(person + 1);
                        firstStaff = false;
                    }
                }
            }
            lines.add(schedule.toString());
        }
        return lines;
    }

    private static String formatRouteLine(String label, List<Integer> route) {
        if (route.size() < 2 || route.get(route.size() - 1) != route.get(0)) {
            throw new IllegalStateException("Selected arcs do not form a closed route: " + route);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(label).append(":");
        for (int node : route) {
            sb.append(' ').append(node);
        }
        return sb.toString();
    }
}
