package mtvrptw;

import common.VRPTWInstance;
import common.SolverChecks;
import common.read_in;
import common.SolutionIO;
import copt.CoptException;
import copt.Envr;
import copt.Expr;
import copt.Model;
import copt.Var;
import java.util.ArrayList;
import java.util.List;

/** 扩展示例：具有仓库卸货时隙容量的多行程 VRPTW。 */
public final class MTVRPTW_Copt {
    private MTVRPTW_Copt() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--help".equals(args[0])) {
            System.out.println("Usage: mtvrptw.MTVRPTW_Copt [instancePath] [timeLimitSec]"
                    + " [vehicleLimit] [customerLimit]");
            return;
        }
        if (args.length > 4) {
            throw new IllegalArgumentException("Too many arguments; use --help.");
        }
        String path = args.length > 0 ? args[0] : "instances/C201.txt";
        double timeLimit = args.length > 1 ? Double.parseDouble(args[1]) : 3600.0;
        int vehicleLimit = args.length > 2 ? Integer.parseInt(args[2]) : 2;
        int customerLimit = args.length > 3 ? Integer.parseInt(args[3]) : 25;
        if (!Double.isFinite(timeLimit) || timeLimit < 0.0) {
            throw new IllegalArgumentException("timeLimitSec must be finite and nonnegative (0 = unlimited).");
        }
        if (vehicleLimit != -1 && vehicleLimit <= 0) {
            throw new IllegalArgumentException("vehicleLimit must be positive or -1 (file default).");
        }
        if (customerLimit < 0) {
            throw new IllegalArgumentException("customerLimit must be nonnegative (0 = all customers).");
        }
        boolean applyMetricClosure = true;
        boolean applyRounding = true;
        boolean applyTruncation = true;
        int tripLimit = -1; // 每车行程上界，-1 表示客户数。
        int unloadCapacity = 1;
        double slotLength = 10.0;
        double unitUnloadTime = 1.0;
        Envr env = null;
        Model model = null;

        try {
            VRPTWInstance inst = read_in.readSolomon(
                    path,
                    customerLimit,
                    applyMetricClosure,
                    applyRounding,
                    applyTruncation);
            SolverChecks.requirePositiveServiceTimes(inst);
            int n = inst.customerCount;
            int nodes = n + 1; // 仅使用单一仓库节点0，不使用复制的终点节点
            int start = inst.start;
            int vehicles = vehicleLimit > 0 ? vehicleLimit : inst.vehicleCount;
            int maxTrips = tripLimit > 0 ? tripLimit : n;
            double capacity = inst.capacity;

            double horizon = inst.due[start];
            if (slotLength <= 0.0) {
                throw new IllegalArgumentException("slotLength must be positive.");
            }
            int slots = (int) Math.ceil(horizon / slotLength);
            if (slots <= 0) {
                slots = 1;
            }

            double[] slotStart = new double[slots + 2];
            for (int u = 1; u <= slots; u++) {
                slotStart[u] = slotLength * (u - 1);
            }
            slotStart[slots + 1] = horizon;

            int maxUnloadSlots = (int) Math.floor(unitUnloadTime * capacity / slotLength) + 1;
            if (maxUnloadSlots < 1) {
                maxUnloadSlots = 1;
            }

            double maxDue = 0.0;
            double maxService = 0.0;
            double maxTravel = 0.0;
            for (int i = 0; i < nodes; i++) {
                if (inst.due[i] > maxDue) {
                    maxDue = inst.due[i];
                }
                if (inst.service[i] > maxService) {
                    maxService = inst.service[i];
                }
                for (int j = 0; j < nodes; j++) {
                    if (inst.travelTime[i][j] > maxTravel) {
                        maxTravel = inst.travelTime[i][j];
                    }
                }
            }
            double bigM = maxDue + maxService + maxTravel;

            env = new Envr();
            model = env.createModel("MTVRPTW_Copt");
            if (timeLimit > 0.0) {
                model.setDblParam(copt.DblParam.TimeLimit, timeLimit);
            }

            Var[][][][] x = new Var[nodes][nodes][maxTrips][vehicles];
            Var[][][][] y = new Var[slots + 1][slots + 1][maxTrips][vehicles];
            Var[] a = new Var[nodes];

            // 时间窗 e_i <= a_i <= l_i（通过变量上下界实现）
            for (int i = 1; i <= n; i++) {
                a[i] = model.addVar(inst.ready[i], inst.due[i], 0.0, copt.Consts.CONTINUOUS,
                        "a_" + i);
            }

            Expr obj = new Expr();
            // x(i,j,k,h) 为0/1，表示弧是否被使用
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int i = 0; i < nodes; i++) {
                        for (int j = 0; j < nodes; j++) {
                            if (i == j) {
                                continue;
                            }
                            x[i][j][k][h] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                                    "x_" + i + "_" + j + "_" + (k + 1) + "_" + (h + 1));
                            obj.addTerm(x[i][j][k][h], inst.distance[i][j]);
                        }
                    }
                }
            }

            // y(u,v,k,h) 为0/1，表示卸货起止时隙选择
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int u = 1; u <= slots; u++) {
                        for (int v = u; v <= slots; v++) {
                            if (v - u + 1 > maxUnloadSlots) {
                                continue;
                            }
                            y[u][v][k][h] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                                    "y_" + u + "_" + v + "_" + (k + 1) + "_" + (h + 1));
                        }
                    }
                }
            }

            // 最小化总行驶距离
            model.setObjective(obj, copt.Consts.MINIMIZE);

            // 卸货时隙容量限制
            for (int t = 1; t <= slots; t++) {
                Expr expr = new Expr();
                for (int h = 0; h < vehicles; h++) {
                    for (int k = 0; k < maxTrips; k++) {
                        for (int u = 1; u <= t; u++) {
                            for (int v = t; v <= slots; v++) {
                                if (y[u][v][k][h] != null) {
                                    expr.addTerm(y[u][v][k][h], 1.0);
                                }
                            }
                        }
                    }
                }
                model.addConstr(expr, copt.Consts.LESS_EQUAL, unloadCapacity, "slot_cap_" + t);
            }

            // 每个车辆-行程最多选择一个卸货区间
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    Expr expr = new Expr();
                    for (int u = 1; u <= slots; u++) {
                        for (int v = u; v <= slots; v++) {
                            if (y[u][v][k][h] != null) {
                                expr.addTerm(y[u][v][k][h], 1.0);
                            }
                        }
                    }
                    model.addConstr(expr, copt.Consts.LESS_EQUAL, 1.0,
                            "unload_once_" + (k + 1) + "_" + (h + 1));
                }
            }

            // 每个客户仅被访问一次
            for (int i = 1; i <= n; i++) {
                Expr expr = new Expr();
                for (int h = 0; h < vehicles; h++) {
                    for (int k = 0; k < maxTrips; k++) {
                        for (int j = 0; j < nodes; j++) {
                            if (j == i) {
                                continue;
                            }
                            if (x[i][j][k][h] != null) {
                                expr.addTerm(x[i][j][k][h], 1.0);
                            }
                        }
                    }
                }
                model.addConstr(expr, copt.Consts.EQUAL, 1.0, "visit_" + i);
            }

            // 同一行程相邻客户的时间连续性
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (i == j) {
                        continue;
                    }
                    Expr expr = new Expr();
                    expr.addTerm(a[j], 1.0);
                    expr.addTerm(a[i], -1.0);
                    for (int h = 0; h < vehicles; h++) {
                        for (int k = 0; k < maxTrips; k++) {
                            if (x[i][j][k][h] != null) {
                                expr.addTerm(x[i][j][k][h], -bigM);
                            }
                        }
                    }
                    double tij = inst.travelTime[i][j] + inst.service[i]; // t_ij 含服务时间
                    model.addConstr(expr, copt.Consts.GREATER_EQUAL, tij - bigM,
                            "time_link_" + i + "_" + j);
                }
            }

            // 首个行程从仓库出发的最早时间
            double s1 = slotStart[1];
            for (int i = 1; i <= n; i++) {
                Expr expr = new Expr();
                expr.addTerm(a[i], 1.0);
                double t0i = inst.travelTime[start][i] + inst.service[start]; // t_0i
                for (int h = 0; h < vehicles; h++) {
                    if (x[start][i][0][h] != null) {
                        expr.addTerm(x[start][i][0][h], -(s1 + t0i));
                    }
                }
                model.addConstr(expr, copt.Consts.GREATER_EQUAL, 0.0, "first_depart_" + i);
            }

            // 相邻行程之间的时间衔接
            int lastSlotForLink = Math.max(1, slots - 1);
            for (int h = 0; h < vehicles; h++) {
                for (int k = 1; k < maxTrips; k++) {
                    for (int i = 1; i <= n; i++) {
                        Expr expr = new Expr();
                        expr.addTerm(a[i], 1.0);
                        if (x[start][i][k][h] != null) {
                            expr.addTerm(x[start][i][k][h], -bigM);
                        }
                        double t0i = inst.travelTime[start][i] + inst.service[start]; // t_0i
                        for (int u = 1; u <= lastSlotForLink; u++) {
                            for (int v = u; v <= lastSlotForLink; v++) {
                                if (y[u][v][k - 1][h] != null) {
                                    expr.addTerm(y[u][v][k - 1][h], -(slotStart[v + 1] + t0i));
                                }
                            }
                        }
                        model.addConstr(expr, copt.Consts.GREATER_EQUAL, -bigM,
                                "trip_link_" + i + "_" + (k + 1) + "_" + (h + 1));
                    }
                }
            }

            // 卸货开始时间不得早于车辆回仓到达时间
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int i = 1; i <= n; i++) {
                        Expr expr = new Expr();
                        expr.addTerm(a[i], 1.0);
                        double ti0 = inst.travelTime[i][start] + inst.service[i]; // t_i0
                        for (int u = 1; u <= slots; u++) {
                            for (int v = u; v <= slots; v++) {
                                if (y[u][v][k][h] != null) {
                                    expr.addTerm(y[u][v][k][h], bigM + ti0 - slotStart[u]);
                                }
                            }
                        }
                        if (x[i][start][k][h] != null) {
                            expr.addTerm(x[i][start][k][h], bigM);
                        }
                        model.addConstr(expr, copt.Consts.LESS_EQUAL, 2.0 * bigM,
                                "unload_start_" + i + "_" + (k + 1) + "_" + (h + 1));
                    }
                }
            }

            // 卸货时长满足需求
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    Expr expr = new Expr();
                    for (int i = 1; i <= n; i++) {
                        for (int j = 0; j < nodes; j++) {
                            if (j == i || x[i][j][k][h] == null) {
                                continue;
                            }
                            expr.addTerm(x[i][j][k][h], unitUnloadTime * inst.demand[i]);
                        }
                    }
                    for (int u = 1; u <= slots; u++) {
                        for (int v = u; v <= slots; v++) {
                            if (y[u][v][k][h] != null) {
                                expr.addTerm(y[u][v][k][h], -(v - u + 1) * slotLength);
                            }
                        }
                    }
                    model.addConstr(expr, copt.Consts.LESS_EQUAL, 0.0,
                            "unload_time_" + (k + 1) + "_" + (h + 1));
                }
            }

            // 单次行程容量限制
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    Expr expr = new Expr();
                    for (int i = 1; i <= n; i++) {
                        for (int j = 0; j < nodes; j++) {
                            if (j == i || x[i][j][k][h] == null) {
                                continue;
                            }
                            expr.addTerm(x[i][j][k][h], inst.demand[i]);
                        }
                    }
                    model.addConstr(expr, copt.Consts.LESS_EQUAL, capacity,
                            "capacity_" + (k + 1) + "_" + (h + 1));
                }
            }

            // 每个行程的流守恒
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int j = 0; j < nodes; j++) {
                        Expr expr = new Expr();
                        for (int i = 0; i < nodes; i++) {
                            if (i == j) {
                                continue;
                            }
                            if (x[i][j][k][h] != null) {
                                expr.addTerm(x[i][j][k][h], 1.0);
                            }
                            if (x[j][i][k][h] != null) {
                                expr.addTerm(x[j][i][k][h], -1.0);
                            }
                        }
                        model.addConstr(expr, copt.Consts.EQUAL, 0.0,
                                "flow_" + j + "_" + (k + 1) + "_" + (h + 1));
                    }
                }
            }

            long solveStart = System.nanoTime();
            model.solve();
            double solveSeconds = (System.nanoTime() - solveStart) / 1e9;
            System.out.println("Solve time (s): " + solveSeconds);
            int status = model.getIntAttr(copt.IntAttr.MipStatus);
            System.out.println("MIP status: " + status);
            if (model.getIntAttr(copt.IntAttr.HasMipSol) != 0) {
                double objective = model.getDblAttr(copt.DblAttr.BestObj);
                double lowerBound = model.getDblAttr(copt.DblAttr.BestBnd);
                double gap = model.getDblAttr(copt.DblAttr.BestGap);
                System.out.println("Objective: " + objective);
                List<String> routeLines = buildRouteLines(x, start, nodes, maxTrips, vehicles);
                String outputPath = SolutionIO.buildSolutionPath(path, "MTVRPTW_Copt");
                SolutionIO.writeSolution(outputPath, path, inst.name, "MTVRPTW_Copt",
                        objective, lowerBound, gap, solveSeconds, Integer.toString(status), routeLines);
                System.out.println("Solution saved to: " + outputPath);
            } else {
                System.out.println("No feasible solution available; status: " + status);
                String outputPath = SolutionIO.buildSolutionPath(path, "MTVRPTW_Copt");
                SolutionIO.writeNoSolution(outputPath, path, inst.name, "MTVRPTW_Copt",
                        Integer.toString(status), solveSeconds);
                System.out.println("Result saved (status only) to: " + outputPath);
            }
        } finally {
            try {
                if (model != null) {
                    model.dispose();
                }
            } finally {
                if (env != null) {
                    env.dispose();
                }
            }
        }
    }

    private static List<String> buildRouteLines(
            Var[][][][] x,
            int start,
            int nodes,
            int maxTrips,
            int vehicles) throws CoptException {
        List<String> lines = new ArrayList<>();
        for (int h = 0; h < vehicles; h++) {
            for (int k = 0; k < maxTrips; k++) {
                for (int j = 0; j < nodes; j++) {
                    if (j == start || x[start][j][k][h] == null) {
                        continue;
                    }
                    if (x[start][j][k][h].get(copt.DblInfo.Value) <= 0.5) {
                        continue;
                    }
                    List<Integer> route = new ArrayList<>();
                    route.add(start);
                    int current = j;
                    route.add(current);
                    int guard = 0;
                    while (current != start && guard < nodes + 2) {
                        int next = -1;
                        for (int m = 0; m < nodes; m++) {
                            if (x[current][m][k][h] != null && x[current][m][k][h].get(copt.DblInfo.Value) > 0.5) {
                                next = m;
                                break;
                            }
                        }
                        if (next == -1) {
                            break;
                        }
                        current = next;
                        route.add(current);
                        guard++;
                    }
                    lines.add(formatRouteLine("route v=" + (h + 1) + " t=" + (k + 1), route));
                }
            }
        }
        return lines;
    }

    private static String formatRouteLine(String label, List<Integer> route) {
        if (route.size() < 2 || route.get(route.size() - 1) != route.get(0)) {
            throw new IllegalStateException("Selected arcs do not form a closed route: " + route);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(label).append(":");
        for (int node : route) {
            sb.append(' ').append(node);
        }
        return sb.toString();
    }
}
