package mtvrptw;

import common.VRPTWInstance;
import common.SolverChecks;
import common.read_in;
import common.SolutionIO;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBEnv;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBLinExpr;
import com.gurobi.gurobi.GRBModel;
import com.gurobi.gurobi.GRBVar;
import java.util.ArrayList;
import java.util.List;

/** 扩展示例：具有仓库卸货时隙容量的多行程 VRPTW。 */
public final class MTVRPTW_Gurobi {
    private MTVRPTW_Gurobi() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--help".equals(args[0])) {
            System.out.println("Usage: mtvrptw.MTVRPTW_Gurobi [instancePath] [timeLimitSec]"
                    + " [vehicleLimit] [customerLimit]");
            return;
        }
        if (args.length > 4) {
            throw new IllegalArgumentException("Too many arguments; use --help.");
        }
        String path = args.length > 0 ? args[0] : "instances/C201.txt";
        double timeLimit = args.length > 1 ? Double.parseDouble(args[1]) : 3600.0;
        int vehicleLimit = args.length > 2 ? Integer.parseInt(args[2]) : 2;
        int customerLimit = args.length > 3 ? Integer.parseInt(args[3]) : 25;
        if (!Double.isFinite(timeLimit) || timeLimit < 0.0) {
            throw new IllegalArgumentException("timeLimitSec must be finite and nonnegative (0 = unlimited).");
        }
        if (vehicleLimit != -1 && vehicleLimit <= 0) {
            throw new IllegalArgumentException("vehicleLimit must be positive or -1 (file default).");
        }
        if (customerLimit < 0) {
            throw new IllegalArgumentException("customerLimit must be nonnegative (0 = all customers).");
        }
        boolean applyMetricClosure = true;
        boolean applyRounding = true;
        boolean applyTruncation = true;
        int tripLimit = -1; // 每车行程上界，-1 表示客户数。
        int unloadCapacity = 1;
        double slotLength = 10.0;
        double unitUnloadTime = 1.0;
        GRBEnv env = null;
        GRBModel model = null;

        try {
            VRPTWInstance inst = read_in.readSolomon(
                    path,
                    customerLimit,
                    applyMetricClosure,
                    applyRounding,
                    applyTruncation);
            SolverChecks.requirePositiveServiceTimes(inst);
            int n = inst.customerCount;
            int nodes = n + 1; // 仅使用单一仓库节点0，不使用复制的终点节点
            int start = inst.start;
            int vehicles = vehicleLimit > 0 ? vehicleLimit : inst.vehicleCount;
            int maxTrips = tripLimit > 0 ? tripLimit : n;
            double capacity = inst.capacity;

            double horizon = inst.due[start];
            if (slotLength <= 0.0) {
                throw new IllegalArgumentException("slotLength must be positive.");
            }
            int slots = (int) Math.ceil(horizon / slotLength);
            if (slots <= 0) {
                slots = 1;
            }

            double[] slotStart = new double[slots + 2];
            for (int u = 1; u <= slots; u++) {
                slotStart[u] = slotLength * (u - 1);
            }
            slotStart[slots + 1] = horizon;

            int maxUnloadSlots = (int) Math.floor(unitUnloadTime * capacity / slotLength) + 1;
            if (maxUnloadSlots < 1) {
                maxUnloadSlots = 1;
            }

            double maxDue = 0.0;
            double maxService = 0.0;
            double maxTravel = 0.0;
            for (int i = 0; i < nodes; i++) {
                if (inst.due[i] > maxDue) {
                    maxDue = inst.due[i];
                }
                if (inst.service[i] > maxService) {
                    maxService = inst.service[i];
                }
                for (int j = 0; j < nodes; j++) {
                    if (inst.travelTime[i][j] > maxTravel) {
                        maxTravel = inst.travelTime[i][j];
                    }
                }
            }
            double bigM = maxDue + maxService + maxTravel;

            env = new GRBEnv();
            model = new GRBModel(env);
            model.set(GRB.StringAttr.ModelName, "MTVRPTW_Gurobi");
            if (timeLimit > 0.0) {
                model.set(GRB.DoubleParam.TimeLimit, timeLimit);
            }

            GRBVar[][][][] x = new GRBVar[nodes][nodes][maxTrips][vehicles];
            GRBVar[][][][] y = new GRBVar[slots + 1][slots + 1][maxTrips][vehicles];
            GRBVar[] a = new GRBVar[nodes];
            GRBLinExpr obj = new GRBLinExpr();

            // 时间窗 e_i <= a_i <= l_i（通过变量上下界实现）
            for (int i = 1; i <= n; i++) {
                a[i] = model.addVar(inst.ready[i], inst.due[i], 0.0, GRB.CONTINUOUS, "a_" + i);
            }

            // x(i,j,k,h) 为0/1，表示弧是否被使用
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int i = 0; i < nodes; i++) {
                        for (int j = 0; j < nodes; j++) {
                            if (i == j) {
                                continue;
                            }
                            x[i][j][k][h] = model.addVar(0.0, 1.0, 0.0, GRB.BINARY,
                                    "x_" + i + "_" + j + "_" + (k + 1) + "_" + (h + 1));
                            obj.addTerm(inst.distance[i][j], x[i][j][k][h]);
                        }
                    }
                }
            }

            // y(u,v,k,h) 为0/1，表示卸货起止时隙选择
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int u = 1; u <= slots; u++) {
                        for (int v = u; v <= slots; v++) {
                            if (v - u + 1 > maxUnloadSlots) {
                                continue;
                            }
                            y[u][v][k][h] = model.addVar(0.0, 1.0, 0.0, GRB.BINARY,
                                    "y_" + u + "_" + v + "_" + (k + 1) + "_" + (h + 1));
                        }
                    }
                }
            }

            model.update();

            // 最小化总行驶距离
            model.setObjective(obj, GRB.MINIMIZE);

            // 卸货时隙容量限制
            for (int t = 1; t <= slots; t++) {
                GRBLinExpr expr = new GRBLinExpr();
                for (int h = 0; h < vehicles; h++) {
                    for (int k = 0; k < maxTrips; k++) {
                        for (int u = 1; u <= t; u++) {
                            for (int v = t; v <= slots; v++) {
                                if (y[u][v][k][h] != null) {
                                    expr.addTerm(1.0, y[u][v][k][h]);
                                }
                            }
                        }
                    }
                }
                model.addConstr(expr, GRB.LESS_EQUAL, unloadCapacity, "slot_cap_" + t);
            }

            // 每个车辆-行程最多选择一个卸货区间
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    GRBLinExpr expr = new GRBLinExpr();
                    for (int u = 1; u <= slots; u++) {
                        for (int v = u; v <= slots; v++) {
                            if (y[u][v][k][h] != null) {
                                expr.addTerm(1.0, y[u][v][k][h]);
                            }
                        }
                    }
                    model.addConstr(expr, GRB.LESS_EQUAL, 1.0,
                            "unload_once_" + (k + 1) + "_" + (h + 1));
                }
            }

            // 每个客户仅被访问一次
            for (int i = 1; i <= n; i++) {
                GRBLinExpr expr = new GRBLinExpr();
                for (int h = 0; h < vehicles; h++) {
                    for (int k = 0; k < maxTrips; k++) {
                        for (int j = 0; j < nodes; j++) {
                            if (j == i) {
                                continue;
                            }
                            if (x[i][j][k][h] != null) {
                                expr.addTerm(1.0, x[i][j][k][h]);
                            }
                        }
                    }
                }
                model.addConstr(expr, GRB.EQUAL, 1.0, "visit_" + i);
            }

            // 同一行程相邻客户的时间连续性
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (i == j) {
                        continue;
                    }
                    GRBLinExpr expr = new GRBLinExpr();
                    expr.addTerm(1.0, a[j]);
                    expr.addTerm(-1.0, a[i]);
                    for (int h = 0; h < vehicles; h++) {
                        for (int k = 0; k < maxTrips; k++) {
                            if (x[i][j][k][h] != null) {
                                expr.addTerm(-bigM, x[i][j][k][h]);
                            }
                        }
                    }
                    double tij = inst.travelTime[i][j] + inst.service[i]; // t_ij 含服务时间
                    model.addConstr(expr, GRB.GREATER_EQUAL, tij - bigM,
                            "time_link_" + i + "_" + j);
                }
            }

            // 首个行程从仓库出发的最早时间
            double s1 = slotStart[1];
            for (int i = 1; i <= n; i++) {
                GRBLinExpr expr = new GRBLinExpr();
                expr.addTerm(1.0, a[i]);
                double t0i = inst.travelTime[start][i] + inst.service[start]; // t_0i
                for (int h = 0; h < vehicles; h++) {
                    if (x[start][i][0][h] != null) {
                        expr.addTerm(-(s1 + t0i), x[start][i][0][h]);
                    }
                }
                model.addConstr(expr, GRB.GREATER_EQUAL, 0.0, "first_depart_" + i);
            }

            // 相邻行程之间的时间衔接
            int lastSlotForLink = Math.max(1, slots - 1);
            for (int h = 0; h < vehicles; h++) {
                for (int k = 1; k < maxTrips; k++) {
                    for (int i = 1; i <= n; i++) {
                        GRBLinExpr expr = new GRBLinExpr();
                        expr.addTerm(1.0, a[i]);
                        if (x[start][i][k][h] != null) {
                            expr.addTerm(-bigM, x[start][i][k][h]);
                        }
                        double t0i = inst.travelTime[start][i] + inst.service[start]; // t_0i
                        for (int u = 1; u <= lastSlotForLink; u++) {
                            for (int v = u; v <= lastSlotForLink; v++) {
                                if (y[u][v][k - 1][h] != null) {
                                    expr.addTerm(-(slotStart[v + 1] + t0i), y[u][v][k - 1][h]);
                                }
                            }
                        }
                        model.addConstr(expr, GRB.GREATER_EQUAL, -bigM,
                                "trip_link_" + i + "_" + (k + 1) + "_" + (h + 1));
                    }
                }
            }

            // 卸货开始时间不得早于车辆回仓到达时间
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int i = 1; i <= n; i++) {
                        GRBLinExpr expr = new GRBLinExpr();
                        expr.addTerm(1.0, a[i]);
                        double ti0 = inst.travelTime[i][start] + inst.service[i]; // t_i0
                        for (int u = 1; u <= slots; u++) {
                            for (int v = u; v <= slots; v++) {
                                if (y[u][v][k][h] != null) {
                                    expr.addTerm(bigM + ti0 - slotStart[u], y[u][v][k][h]);
                                }
                            }
                        }
                        if (x[i][start][k][h] != null) {
                            expr.addTerm(bigM, x[i][start][k][h]);
                        }
                        model.addConstr(expr, GRB.LESS_EQUAL, 2.0 * bigM,
                                "unload_start_" + i + "_" + (k + 1) + "_" + (h + 1));
                    }
                }
            }

            // 卸货时长满足需求
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    GRBLinExpr expr = new GRBLinExpr();
                    for (int i = 1; i <= n; i++) {
                        for (int j = 0; j < nodes; j++) {
                            if (j == i || x[i][j][k][h] == null) {
                                continue;
                            }
                            expr.addTerm(unitUnloadTime * inst.demand[i], x[i][j][k][h]);
                        }
                    }
                    for (int u = 1; u <= slots; u++) {
                        for (int v = u; v <= slots; v++) {
                            if (y[u][v][k][h] != null) {
                                expr.addTerm(-(v - u + 1) * slotLength, y[u][v][k][h]);
                            }
                        }
                    }
                    model.addConstr(expr, GRB.LESS_EQUAL, 0.0,
                            "unload_time_" + (k + 1) + "_" + (h + 1));
                }
            }

            // 单次行程容量限制
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    GRBLinExpr expr = new GRBLinExpr();
                    for (int i = 1; i <= n; i++) {
                        for (int j = 0; j < nodes; j++) {
                            if (j == i || x[i][j][k][h] == null) {
                                continue;
                            }
                            expr.addTerm(inst.demand[i], x[i][j][k][h]);
                        }
                    }
                    model.addConstr(expr, GRB.LESS_EQUAL, capacity,
                            "capacity_" + (k + 1) + "_" + (h + 1));
                }
            }

            // 每个行程的流守恒
            for (int h = 0; h < vehicles; h++) {
                for (int k = 0; k < maxTrips; k++) {
                    for (int j = 0; j < nodes; j++) {
                        GRBLinExpr expr = new GRBLinExpr();
                        for (int i = 0; i < nodes; i++) {
                            if (i == j) {
                                continue;
                            }
                            if (x[i][j][k][h] != null) {
                                expr.addTerm(1.0, x[i][j][k][h]);
                            }
                            if (x[j][i][k][h] != null) {
                                expr.addTerm(-1.0, x[j][i][k][h]);
                            }
                        }
                        model.addConstr(expr, GRB.EQUAL, 0.0,
                                "flow_" + j + "_" + (k + 1) + "_" + (h + 1));
                    }
                }
            }

            long solveStart = System.nanoTime();
            model.optimize();
            double solveSeconds = (System.nanoTime() - solveStart) / 1e9;
            System.out.println("Solve time (s): " + solveSeconds);

            int status = model.get(GRB.IntAttr.Status);
            System.out.println("MIP status: " + status);
            if (model.get(GRB.IntAttr.SolCount) > 0) {
                double objective = model.get(GRB.DoubleAttr.ObjVal);
                double lowerBound = model.get(GRB.DoubleAttr.ObjBound);
                double gap = model.get(GRB.DoubleAttr.MIPGap);
                System.out.println("Objective: " + objective);
                List<String> routeLines = buildRouteLines(x, start, nodes, maxTrips, vehicles);
                String outputPath = SolutionIO.buildSolutionPath(path, "MTVRPTW_Gurobi");
                SolutionIO.writeSolution(outputPath, path, inst.name, "MTVRPTW_Gurobi",
                        objective, lowerBound, gap, solveSeconds, Integer.toString(status), routeLines);
                System.out.println("Solution saved to: " + outputPath);
            } else {
                System.out.println("No feasible solution available; status: " + status);
                String outputPath = SolutionIO.buildSolutionPath(path, "MTVRPTW_Gurobi");
                SolutionIO.writeNoSolution(outputPath, path, inst.name, "MTVRPTW_Gurobi",
                        Integer.toString(status), solveSeconds);
                System.out.println("Result saved (status only) to: " + outputPath);
            }

        } finally {
            try {
                if (model != null) {
                    model.dispose();
                }
            } finally {
                if (env != null) {
                    env.dispose();
                }
            }
        }
    }

    private static List<String> buildRouteLines(
            GRBVar[][][][] x,
            int start,
            int nodes,
            int maxTrips,
            int vehicles) throws GRBException {
        List<String> lines = new ArrayList<>();
        for (int h = 0; h < vehicles; h++) {
            for (int k = 0; k < maxTrips; k++) {
                for (int j = 0; j < nodes; j++) {
                    if (j == start || x[start][j][k][h] == null) {
                        continue;
                    }
                    if (x[start][j][k][h].get(GRB.DoubleAttr.X) <= 0.5) {
                        continue;
                    }
                    List<Integer> route = new ArrayList<>();
                    route.add(start);
                    int current = j;
                    route.add(current);
                    int guard = 0;
                    while (current != start && guard < nodes + 2) {
                        int next = -1;
                        for (int m = 0; m < nodes; m++) {
                            if (x[current][m][k][h] != null
                                    && x[current][m][k][h].get(GRB.DoubleAttr.X) > 0.5) {
                                next = m;
                                break;
                            }
                        }
                        if (next == -1) {
                            break;
                        }
                        current = next;
                        route.add(current);
                        guard++;
                    }
                    lines.add(formatRouteLine("route v=" + (h + 1) + " t=" + (k + 1), route));
                }
            }
        }
        return lines;
    }

    private static String formatRouteLine(String label, List<Integer> route) {
        if (route.size() < 2 || route.get(route.size() - 1) != route.get(0)) {
            throw new IllegalStateException("Selected arcs do not form a closed route: " + route);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(label).append(":");
        for (int node : route) {
            sb.append(' ').append(node);
        }
        return sb.toString();
    }
}
