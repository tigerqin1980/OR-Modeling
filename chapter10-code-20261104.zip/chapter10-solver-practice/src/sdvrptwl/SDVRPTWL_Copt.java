package sdvrptwl;

import common.VRPTWInstance;
import common.SolverChecks;
import common.read_in;
import common.SolutionIO;
import copt.CoptException;
import copt.Envr;
import copt.Expr;
import copt.Model;
import copt.Var;
import java.util.ArrayList;
import java.util.List;

/** 可拆分配送 VRPTW：弧载重流决定各车的配送量。 */
public final class SDVRPTWL_Copt {
    private SDVRPTWL_Copt() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--help".equals(args[0])) {
            System.out.println("Usage: sdvrptwl.SDVRPTWL_Copt [instancePath] [timeLimitSec]"
                    + " [vehicleLimit] [customerLimit]");
            return;
        }
        if (args.length > 4) {
            throw new IllegalArgumentException("Too many arguments; use --help.");
        }
        String path = args.length > 0 ? args[0] : "instances/C201.txt";
        double timeLimit = args.length > 1 ? Double.parseDouble(args[1]) : 3600.0;
        int vehicleLimit = args.length > 2 ? Integer.parseInt(args[2]) : 20;
        int customerLimit = args.length > 3 ? Integer.parseInt(args[3]) : 25;
        if (!Double.isFinite(timeLimit) || timeLimit < 0.0) {
            throw new IllegalArgumentException("timeLimitSec must be finite and nonnegative (0 = unlimited).");
        }
        if (vehicleLimit != -1 && vehicleLimit <= 0) {
            throw new IllegalArgumentException("vehicleLimit must be positive or -1 (file default).");
        }
        if (customerLimit < 0) {
            throw new IllegalArgumentException("customerLimit must be nonnegative (0 = all customers).");
        }
        boolean applyMetricClosure = true;
        boolean applyRounding = true;
        boolean applyTruncation = true;
        double weightA = 0.0; // 载重与距离乘积的成本系数。
        double weightB = 1.0; // 纯距离成本系数。
        double capacityLimit = 30.0;
        Envr env = null;
        Model model = null;

        try {
            VRPTWInstance inst = read_in.readSolomon(
                    path,
                    customerLimit,
                    applyMetricClosure,
                    applyRounding,
                    applyTruncation);
            SolverChecks.requirePositiveServiceTimes(inst);
            int n = inst.customerCount;
            int start = inst.start;
            int end = inst.end;
            int nodes = inst.nodeCount;
            int vehicles = vehicleLimit > 0 ? vehicleLimit : inst.vehicleCount;
            double capacity = capacityLimit;

            env = new Envr();
            model = env.createModel("SDVRPTWL_Copt");
            if (timeLimit > 0.0) {
                model.setDblParam(copt.DblParam.TimeLimit, timeLimit);
            }

            Var[][][] x = new Var[nodes][nodes][vehicles];
            Var[][][] w = new Var[nodes][nodes][vehicles];
            Var[][] a = new Var[nodes][vehicles];
            Expr obj = new Expr();

            for (int k = 0; k < vehicles; k++) {
                for (int i = 0; i < nodes; i++) {
                    if (i == end) {
                        continue;
                    }
                    for (int j = 0; j < nodes; j++) {
                        if (i == j || j == start) {
                            continue;
                        }
                        x[i][j][k] = model.addVar(0.0, 1.0, 0.0, copt.Consts.BINARY,
                                "x_" + i + "_" + j + "_" + k);
                        w[i][j][k] = model.addVar(0.0, capacity, 0.0, copt.Consts.CONTINUOUS,
                                "w_" + i + "_" + j + "_" + k);
                        obj.addTerm(x[i][j][k], inst.distance[i][j] * weightB);
                        obj.addTerm(w[i][j][k], inst.distance[i][j] * weightA);
                    }
                }
            }

            for (int k = 0; k < vehicles; k++) {
                for (int i = 0; i < nodes; i++) {
                    double lb = inst.ready[i];
                    double ub = inst.due[i];
                    if (i == start) {
                        lb = inst.ready[start];
                        ub = inst.ready[start];
                    }
                    a[i][k] = model.addVar(lb, ub, 0.0, copt.Consts.CONTINUOUS,
                            "a_" + i + "_" + k);
                }
            }

            for (int k = 0; k < vehicles; k++) {
                Expr startExpr = new Expr();
                Expr endExpr = new Expr();
                for (int j = 0; j < nodes; j++) {
                    if (x[start][j][k] != null) {
                        startExpr.addTerm(x[start][j][k], 1.0);
                    }
                }
                for (int i = 0; i < nodes; i++) {
                    if (x[i][end][k] != null) {
                        endExpr.addTerm(x[i][end][k], 1.0);
                    }
                }
                model.addConstr(startExpr, copt.Consts.EQUAL, 1.0, "start_" + k);
                model.addConstr(endExpr, copt.Consts.EQUAL, 1.0, "end_" + k);
            }

            for (int k = 0; k < vehicles; k++) {
                for (int i = 1; i <= n; i++) {
                    Expr outExpr = new Expr();
                    Expr flowExpr = new Expr();
                    for (int j = 0; j < nodes; j++) {
                        if (x[i][j][k] != null) {
                            outExpr.addTerm(x[i][j][k], 1.0);
                            flowExpr.addTerm(x[i][j][k], 1.0);
                        }
                        if (x[j][i][k] != null) {
                            flowExpr.addTerm(x[j][i][k], -1.0);
                        }
                    }
                    model.addConstr(flowExpr, copt.Consts.EQUAL, 0.0, "flow_" + i + "_" + k);
                    model.addConstr(outExpr, copt.Consts.LESS_EQUAL, 1.0, "visit_" + i + "_" + k);
                }
            }

            for (int i = 1; i <= n; i++) {
                Expr demandExpr = new Expr();
                for (int k = 0; k < vehicles; k++) {
                    for (int j = 0; j < nodes; j++) {
                        if (w[j][i][k] != null) {
                            demandExpr.addTerm(w[j][i][k], 1.0);
                        }
                        if (w[i][j][k] != null) {
                            demandExpr.addTerm(w[i][j][k], -1.0);
                        }
                    }
                }
                model.addConstr(demandExpr, copt.Consts.EQUAL, inst.demand[i], "demand_" + i);
            }

            for (int k = 0; k < vehicles; k++) {
                for (int i = 1; i <= n; i++) {
                    Expr deliverExpr = new Expr();
                    for (int j = 0; j < nodes; j++) {
                        if (w[j][i][k] != null) {
                            deliverExpr.addTerm(w[j][i][k], 1.0);
                        }
                        if (w[i][j][k] != null) {
                            deliverExpr.addTerm(w[i][j][k], -1.0);
                        }
                    }
                    model.addConstr(deliverExpr, copt.Consts.GREATER_EQUAL, 0.0,
                            "deliver_nonneg_" + i + "_" + k);
                }
            }

            for (int i = 1; i <= n; i++) {
                Expr minVeh = new Expr();
                for (int k = 0; k < vehicles; k++) {
                    for (int j = 0; j < nodes; j++) {
                        if (x[j][i][k] != null) {
                            minVeh.addTerm(x[j][i][k], 1.0);
                        }
                    }
                }
                model.addConstr(minVeh, copt.Consts.GREATER_EQUAL, Math.ceil(inst.demand[i] / capacity),
                        "minveh_" + i);
            }

            for (int k = 0; k < vehicles; k++) {
                for (int i = 0; i < nodes; i++) {
                    if (i == end) {
                        continue;
                    }
                    for (int j = 0; j < nodes; j++) {
                        if (x[i][j][k] == null) {
                            continue;
                        }
                        Expr capExpr = new Expr();
                        capExpr.addTerm(w[i][j][k], 1.0);
                        capExpr.addTerm(x[i][j][k], -capacity);
                        model.addConstr(capExpr, copt.Consts.LESS_EQUAL, 0.0,
                                "cap_" + i + "_" + j + "_" + k);

                        double bigM = Math.max(0.0, inst.due[i] + inst.service[i]
                                + inst.travelTime[i][j] - inst.ready[j]);
                        Expr timeExpr = new Expr();
                        timeExpr.addTerm(a[j][k], 1.0);
                        timeExpr.addTerm(a[i][k], -1.0);
                        timeExpr.addTerm(x[i][j][k], -bigM);
                        model.addConstr(timeExpr, copt.Consts.GREATER_EQUAL,
                                inst.service[i] + inst.travelTime[i][j] - bigM,
                                "time_" + i + "_" + j + "_" + k);
                    }
                }
            }

            model.setObjective(obj, copt.Consts.MINIMIZE);
            long solveStart = System.nanoTime();
            model.solve();
            double solveSeconds = (System.nanoTime() - solveStart) / 1e9;
            System.out.println("Solve time (s): " + solveSeconds);

            int status = model.getIntAttr(copt.IntAttr.MipStatus);
            System.out.println("MIP status: " + status);
            if (model.getIntAttr(copt.IntAttr.HasMipSol) != 0) {
                double objective = model.getDblAttr(copt.DblAttr.BestObj);
                double lowerBound = model.getDblAttr(copt.DblAttr.BestBnd);
                double gap = model.getDblAttr(copt.DblAttr.BestGap);
                System.out.println("Objective: " + objective);
                List<String> routeLines = buildRouteLines(x, w, start, end, vehicles);
                String outputPath = SolutionIO.buildSolutionPath(path, "SDVRPTWL_Copt");
                SolutionIO.writeSolution(outputPath, path, inst.name, "SDVRPTWL_Copt",
                        objective, lowerBound, gap, solveSeconds, Integer.toString(status), routeLines);
                System.out.println("Solution saved to: " + outputPath);
            } else {
                System.out.println("No feasible solution available; status: " + status);
                String outputPath = SolutionIO.buildSolutionPath(path, "SDVRPTWL_Copt");
                SolutionIO.writeNoSolution(outputPath, path, inst.name, "SDVRPTWL_Copt",
                        Integer.toString(status), solveSeconds);
                System.out.println("Result saved (status only) to: " + outputPath);
            }
        } finally {
            try {
                if (model != null) {
                    model.dispose();
                }
            } finally {
                if (env != null) {
                    env.dispose();
                }
            }
        }
    }

    private static List<String> buildRouteLines(
            Var[][][] x,
            Var[][][] w,
            int start,
            int end,
            int vehicles) throws CoptException {
        int nodes = x.length;
        List<String> lines = new ArrayList<>();
        for (int k = 0; k < vehicles; k++) {
            List<Integer> route = new ArrayList<>();
            route.add(start);
            int current = start;
            int guard = 0;
            while (current != end && guard < nodes + 2) {
                int next = -1;
                for (int j = 0; j < nodes; j++) {
                    if (x[current][j][k] != null && x[current][j][k].get(copt.DblInfo.Value) > 0.5) {
                        next = j;
                        break;
                    }
                }
                if (next == -1) {
                    break;
                }
                current = next;
                route.add(current);
                guard++;
            }
            if (route.size() > 2) {
                lines.add(formatRouteLine("route v=" + (k + 1), route, start, end));
            }
        }
        // 每车净送货量 = 入弧载重 - 出弧载重；只记录实际发生的配送。
        for (int k = 0; k < vehicles; k++) {
            for (int i = 1; i < end; i++) {
                double delivered = 0.0;
                for (int j = 0; j < nodes; j++) {
                    if (w[j][i][k] != null) {
                        delivered += w[j][i][k].get(copt.DblInfo.Value);
                    }
                    if (w[i][j][k] != null) {
                        delivered -= w[i][j][k].get(copt.DblInfo.Value);
                    }
                }
                if (delivered > 1e-6) {
                    lines.add("delivery vehicle=" + (k + 1) + " customer=" + i + " amount=" + delivered);
                }
            }
        }
        return lines;
    }

    private static String formatRouteLine(String label, List<Integer> route, int start, int end) {
        if (route.size() < 2 || route.get(route.size() - 1) != end) {
            throw new IllegalStateException("Selected arcs do not form a closed route: " + route);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(label).append(":");
        for (int node : route) {
            int outputNode = node == end ? start : node;
            sb.append(' ').append(outputNode);
        }
        return sb.toString();
    }
}
