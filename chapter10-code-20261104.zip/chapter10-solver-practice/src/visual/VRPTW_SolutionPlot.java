package visual;

import common.SolutionIO;
import common.VRPTWInstance;
import common.read_in;
import common.read_in_MTVRPTW_msm;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public final class VRPTW_SolutionPlot {
    private VRPTW_SolutionPlot() {
    }

    private static final int WIDTH = 1000;
    private static final int HEIGHT = 1000;
    private static final int MARGIN = 110;
    private static final int TICK_COUNT = 6;
    private static final int GRID_TICK_SIZE = 6;
    private static final Color GRID_COLOR = new Color(230, 230, 230);
    private static final Color AXIS_COLOR = new Color(80, 80, 80);
    private static final Color TICK_COLOR = new Color(40, 40, 40);
    private static final Color CUSTOMER_COLOR = Color.BLACK;
    private static final Color DEPOT_COLOR = new Color(70, 70, 70);
    private static final Font TITLE_FONT = new Font("Times New Roman", Font.PLAIN, 26);
    private static final Font AXIS_FONT = new Font("Times New Roman", Font.PLAIN, 19);
    private static final Font AXIS_LABEL_FONT = new Font("Times New Roman", Font.PLAIN, 21);
    private static final Font LEGEND_FONT = new Font("Times New Roman", Font.PLAIN, 19);

    public static void main(String[] args) throws IOException {
        if (args.length == 0) {
            throw new IllegalArgumentException(
                    "Usage: VRPTW_SolutionPlot <solution.txt> [output.png] [instance.txt] [--show]");
        }
        String solutionPath = args[0];
        String outputPath = null;
        String instanceOverride = null;
        boolean show = false;

        for (int i = 1; i < args.length; i++) {
            String arg = args[i];
            if ("--show".equalsIgnoreCase(arg)) {
                show = true;
                continue;
            }
            if (outputPath == null) {
                outputPath = arg;
                continue;
            }
            if (instanceOverride == null) {
                instanceOverride = arg;
            } else {
                throw new IllegalArgumentException("Unexpected argument: " + arg);
            }
        }

        SolutionIO.SolutionData data = SolutionIO.readSolution(solutionPath);
        if (data.routes.isEmpty()) {
            throw new IllegalArgumentException("The result has no routes to plot.");
        }
        String instancePath = instanceOverride != null ? instanceOverride : data.instancePath;
        if (instancePath == null || instancePath.isEmpty()) {
            throw new IllegalArgumentException("Missing instancePath in solution file or arguments.");
        }
        // 求解结果覆盖所有入模客户；最大编号用于恢复截取规模。
        int customerLimit = data.routes.stream().flatMap(List::stream).mapToInt(Integer::intValue).max().orElse(0);
        boolean msm = data.solverName != null && data.solverName.contains("MSM");
        VRPTWInstance inst = msm
                ? read_in_MTVRPTW_msm.readSolomonMSM(instancePath, customerLimit, false, false, false).base
                : read_in.readSolomon(instancePath, customerLimit, false, false, false);
        if (outputPath == null) {
            outputPath = defaultOutputPath(solutionPath);
        }
        String title = data.instanceName != null ? data.instanceName : inst.name;
        BufferedImage image = render(inst, data.routes, title);
        Path output = Path.of(outputPath).toAbsolutePath();
        Files.createDirectories(output.getParent());
        ImageIO.write(image, "png", output.toFile());
        System.out.println("Plot saved to: " + outputPath);
        if (show) {
            javax.swing.SwingUtilities.invokeLater(() -> showImage(image, title));
        }
    }

    private static String defaultOutputPath(String solutionPath) {
        File file = new File(solutionPath);
        String name = file.getName();
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            name = name.substring(0, dot);
        }
        File parent = file.getParentFile();
        File out = parent == null ? new File(name + ".png") : new File(parent, name + ".png");
        return out.getPath();
    }

    private static BufferedImage render(VRPTWInstance inst, List<List<Integer>> routes, String title) {
        BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, WIDTH, HEIGHT);

        Bounds bounds = padBounds(computeBounds(inst), 0.05);
        PlotArea area = createPlotArea(bounds);

        drawGridAndAxes(g, area);
        drawRoutes(g, inst, routes, area);
        drawNodes(g, inst, area);
        drawTitle(g, title);
        drawLegend(g, area);

        g.dispose();
        return image;
    }

    private static void drawRoutes(
            Graphics2D g,
            VRPTWInstance inst,
            List<List<Integer>> routes,
            PlotArea area) {
        int routeCount = routes.isEmpty() ? 1 : routes.size();
        g.setStroke(new BasicStroke(1.0f));
        for (int i = 0; i < routes.size(); i++) {
            List<Integer> route = routes.get(i);
            g.setColor(routeColor(i, routeCount));
            for (int j = 0; j + 1 < route.size(); j++) {
                int from = normalizeNode(route.get(j), inst);
                int to = normalizeNode(route.get(j + 1), inst);
                if (!isValidNode(from, inst) || !isValidNode(to, inst)) {
                    continue;
                }
                Point p1 = toPoint(inst.x[from], inst.y[from], area);
                Point p2 = toPoint(inst.x[to], inst.y[to], area);
                g.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
        }
    }

    private static void drawNodes(Graphics2D g, VRPTWInstance inst, PlotArea area) {
        int depot = inst.start;
        int depotSize = 9;
        int customerSize = 5;

        g.setColor(CUSTOMER_COLOR);
        for (int i = 1; i <= inst.customerCount; i++) {
            Point p = toPoint(inst.x[i], inst.y[i], area);
            g.fillOval(p.x - customerSize / 2, p.y - customerSize / 2, customerSize, customerSize);
        }

        Point depotPoint = toPoint(inst.x[depot], inst.y[depot], area);
        g.setColor(DEPOT_COLOR);
        g.fillRect(depotPoint.x - depotSize / 2, depotPoint.y - depotSize / 2, depotSize, depotSize);
    }

    private static void drawTitle(Graphics2D g, String title) {
        g.setColor(TICK_COLOR);
        g.setFont(TITLE_FONT);
        String text = "Solution of " + title;
        int textWidth = g.getFontMetrics().stringWidth(text);
        int y = Math.max(30, MARGIN - 45);
        g.drawString(text, Math.max(MARGIN, (WIDTH - textWidth) / 2), y);
    }

    private static void drawLegend(Graphics2D g, PlotArea area) {
        int boxWidth = 190;
        int boxHeight = 80;
        int padding = 8;
        int x = area.right - boxWidth - padding;
        int y = area.top + padding;

        g.setColor(new Color(255, 255, 255, 230));
        g.fillRect(x, y, boxWidth, boxHeight);
        g.setColor(AXIS_COLOR);
        g.drawRect(x, y, boxWidth, boxHeight);

        g.setFont(LEGEND_FONT);
        g.setColor(DEPOT_COLOR);
        g.fillRect(x + 12, y + 16, 12, 12);
        g.setColor(TICK_COLOR);
        g.drawString("depot", x + 36, y + 28);

        g.setColor(CUSTOMER_COLOR);
        g.fillOval(x + 13, y + 44, 10, 10);
        g.setColor(TICK_COLOR);
        g.drawString("customer", x + 36, y + 56);
    }

    private static Point toPoint(double x, double y, PlotArea area) {
        int px = (int) Math.round(area.offsetX + (x - area.bounds.minX) * area.scale);
        int py = (int) Math.round(area.offsetY - (y - area.bounds.minY) * area.scale);
        return new Point(px, py);
    }

    private static int toX(double x, PlotArea area) {
        return (int) Math.round(area.offsetX + (x - area.bounds.minX) * area.scale);
    }

    private static int toY(double y, PlotArea area) {
        return (int) Math.round(area.offsetY - (y - area.bounds.minY) * area.scale);
    }

    private static PlotArea createPlotArea(Bounds bounds) {
        int left = MARGIN;
        int right = WIDTH - MARGIN;
        int top = MARGIN;
        int bottom = HEIGHT - MARGIN;
        double rangeX = Math.max(1e-6, bounds.maxX - bounds.minX);
        double rangeY = Math.max(1e-6, bounds.maxY - bounds.minY);
        double plotWidth = right - left;
        double plotHeight = bottom - top;
        double scale = Math.min(plotWidth / rangeX, plotHeight / rangeY);
        double offsetX = left + (plotWidth - rangeX * scale) / 2.0;
        double offsetY = bottom - (plotHeight - rangeY * scale) / 2.0;
        return new PlotArea(left, right, top, bottom, offsetX, offsetY, scale, bounds);
    }

    private static void drawGridAndAxes(Graphics2D g, PlotArea area) {
        TickSpec xTicks = createTickSpec(area.bounds.minX, area.bounds.maxX, TICK_COUNT);
        TickSpec yTicks = createTickSpec(area.bounds.minY, area.bounds.maxY, TICK_COUNT);

        g.setStroke(new BasicStroke(0.8f));
        g.setColor(GRID_COLOR);
        for (double x = xTicks.start; x <= xTicks.end + 1e-9; x += xTicks.step) {
            int px = toX(x, area);
            g.drawLine(px, area.top, px, area.bottom);
        }
        for (double y = yTicks.start; y <= yTicks.end + 1e-9; y += yTicks.step) {
            int py = toY(y, area);
            g.drawLine(area.left, py, area.right, py);
        }

        g.setStroke(new BasicStroke(1.0f));
        g.setColor(AXIS_COLOR);
        g.drawRect(area.left, area.top, area.right - area.left, area.bottom - area.top);

        g.setFont(AXIS_FONT);
        g.setColor(TICK_COLOR);
        for (double x = xTicks.start; x <= xTicks.end + 1e-9; x += xTicks.step) {
            int px = toX(x, area);
            g.drawLine(px, area.bottom, px, area.bottom + GRID_TICK_SIZE);
            String label = formatTick(x, xTicks.step);
            int labelWidth = g.getFontMetrics().stringWidth(label);
            g.drawString(label, px - labelWidth / 2, area.bottom + 24);
        }
        for (double y = yTicks.start; y <= yTicks.end + 1e-9; y += yTicks.step) {
            int py = toY(y, area);
            g.drawLine(area.left - GRID_TICK_SIZE, py, area.left, py);
            String label = formatTick(y, yTicks.step);
            int labelWidth = g.getFontMetrics().stringWidth(label);
            int labelY = py + g.getFontMetrics().getAscent() / 2 - 3;
            g.drawString(label, area.left - GRID_TICK_SIZE - 6 - labelWidth, labelY);
        }

        g.setFont(AXIS_LABEL_FONT);
        String xLabel = "x";
        int xLabelWidth = g.getFontMetrics().stringWidth(xLabel);
        g.drawString(xLabel, (area.left + area.right - xLabelWidth) / 2, area.bottom + 56);

        String yLabel = "y";
        AffineTransform original = g.getTransform();
        g.translate(area.left - 60, (area.top + area.bottom) / 2.0);
        g.rotate(-Math.PI / 2.0);
        int yLabelWidth = g.getFontMetrics().stringWidth(yLabel);
        g.drawString(yLabel, -yLabelWidth / 2, 0);
        g.setTransform(original);
    }

    private static TickSpec createTickSpec(double min, double max, int targetTicks) {
        double range = niceNumber(max - min, false);
        double step = niceNumber(range / Math.max(1, targetTicks - 1), true);
        double start = Math.floor(min / step) * step;
        double end = Math.ceil(max / step) * step;
        return new TickSpec(start, end, step);
    }

    private static double niceNumber(double value, boolean round) {
        if (value <= 0) {
            return 1.0;
        }
        double exponent = Math.floor(Math.log10(value));
        double fraction = value / Math.pow(10.0, exponent);
        double niceFraction;
        if (round) {
            if (fraction < 1.5) {
                niceFraction = 1.0;
            } else if (fraction < 3.0) {
                niceFraction = 2.0;
            } else if (fraction < 7.0) {
                niceFraction = 5.0;
            } else {
                niceFraction = 10.0;
            }
        } else {
            if (fraction <= 1.0) {
                niceFraction = 1.0;
            } else if (fraction <= 2.0) {
                niceFraction = 2.0;
            } else if (fraction <= 5.0) {
                niceFraction = 5.0;
            } else {
                niceFraction = 10.0;
            }
        }
        return niceFraction * Math.pow(10.0, exponent);
    }

    private static String formatTick(double value, double step) {
        int decimals = Math.max(0, -(int) Math.floor(Math.log10(step)));
        double scale = Math.pow(10.0, decimals);
        double rounded = Math.round(value * scale) / scale;
        String format = decimals == 0 ? "%.0f" : "%." + decimals + "f";
        return String.format(Locale.US, format, rounded);
    }

    private static Bounds padBounds(Bounds bounds, double fraction) {
        double dx = bounds.maxX - bounds.minX;
        double dy = bounds.maxY - bounds.minY;
        if (dx <= 0) {
            dx = 1.0;
        }
        if (dy <= 0) {
            dy = 1.0;
        }
        double padX = dx * fraction;
        double padY = dy * fraction;
        return new Bounds(bounds.minX - padX, bounds.minY - padY,
                bounds.maxX + padX, bounds.maxY + padY);
    }

    private static Color routeColor(int index, int total) {
        float hue = total <= 1 ? 0.0f : (float) index / (float) total;
        Color base = Color.getHSBColor(hue, 0.25f, 0.55f);
        return new Color(base.getRed(), base.getGreen(), base.getBlue(), 170);
    }

    private static Bounds computeBounds(VRPTWInstance inst) {
        double minX = Double.POSITIVE_INFINITY;
        double minY = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY;
        double maxY = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < inst.nodeCount; i++) {
            minX = Math.min(minX, inst.x[i]);
            maxX = Math.max(maxX, inst.x[i]);
            minY = Math.min(minY, inst.y[i]);
            maxY = Math.max(maxY, inst.y[i]);
        }
        return new Bounds(minX, minY, maxX, maxY);
    }

    private static final class PlotArea {
        final int left;
        final int right;
        final int top;
        final int bottom;
        final double offsetX;
        final double offsetY;
        final double scale;
        final Bounds bounds;

        PlotArea(
                int left,
                int right,
                int top,
                int bottom,
                double offsetX,
                double offsetY,
                double scale,
                Bounds bounds) {
            this.left = left;
            this.right = right;
            this.top = top;
            this.bottom = bottom;
            this.offsetX = offsetX;
            this.offsetY = offsetY;
            this.scale = scale;
            this.bounds = bounds;
        }
    }

    private static final class TickSpec {
        final double start;
        final double end;
        final double step;

        TickSpec(double start, double end, double step) {
            this.start = start;
            this.end = end;
            this.step = step;
        }
    }

    private static int normalizeNode(int node, VRPTWInstance inst) {
        if (node == inst.end) {
            return inst.start;
        }
        return node;
    }

    private static boolean isValidNode(int node, VRPTWInstance inst) {
        return node >= 0 && node < inst.nodeCount;
    }

    private static void showImage(BufferedImage image, String title) {
        JFrame frame = new JFrame("VRPTW Solution - " + title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new JLabel(new ImageIcon(image)));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static final class Bounds {
        final double minX;
        final double minY;
        final double maxX;
        final double maxY;

        Bounds(double minX, double minY, double maxX, double maxY) {
            this.minX = minX;
            this.minY = minY;
            this.maxX = maxX;
            this.maxY = maxY;
        }
    }
}
