param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$Class,
    [switch]$NoBuild,
    [Parameter(Position = 1, ValueFromRemainingArguments = $true)]
    [string[]]$Arguments
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/scripts/solver-env.ps1"
$solver = if ($Class -match 'Gurobi|^SimpleMIPExample$') { 'Gurobi' }
          elseif ($Class -match 'Copt') { 'Copt' } else { 'None' }
if (-not $NoBuild) { & "$PSScriptRoot/build.ps1" -Solver $solver }
$classpath = @(Join-Path $PSScriptRoot 'build/classes')
$savedPath = $env:PATH
try {
    if ($solver -ne 'None') {
        $config = Get-SolverConfig $solver
        $classpath += $config.Jar
        $env:PATH = $config.NativeDir + [IO.Path]::PathSeparator + $env:PATH
    }
    Push-Location -LiteralPath $PSScriptRoot
    try {
        & java '-Dfile.encoding=UTF-8' -cp ($classpath -join [IO.Path]::PathSeparator) $Class @Arguments
        if ($LASTEXITCODE -ne 0) { throw "Java exited with code $LASTEXITCODE." }
    } finally { Pop-Location }
} finally { $env:PATH = $savedPath }
